<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <link rel="stylesheet" type="text/css" href="Css.css">
  <title>High School Student Records</title>

 </head>
 
 
 <body>
	<div class="wrapper">
		<h1> Student Profile </h1>
		
		<div class="infoPage">
			<div id="photo"> <img src="monkey.jpg" width="175" height="150"> </div>
			<div id="studentInfo">
			  <p>Name </p>
			  <p>Year </p>
			  <p>GPA </p>
			  <p>Advisor </p>
			</div>

		</div>
		
		<div class='calLink'>
			<div id="calendar"> <img src="calendar.jpg" width="175" height="150">  </div>
			
			<div class="quicklinks"> 
				<span style="PADDING:10px"><font size="5"> Quick Links </font></span>
				
				<a href="courses.php">Courses</a> 
				<a href="url">Assignments</a> 
				<a href="url">Advisors</a> 
				<a href="teacher_searchpage.php">Teachers</a> 
				<a href="url">Email</a> 
				
			</div>
		</div>
		
		
		
	</div>
</body>
</html>
