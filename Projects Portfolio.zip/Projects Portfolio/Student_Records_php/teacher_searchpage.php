<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <link rel="stylesheet" type="text/css" href="Css.css">
  <title>High School Student Records</title>

 </head>
 
 <script type="text/javascript">
 
 /*
 $(document).ready(function(){
    $('.editbtn').click(function(){
        $(this).html($(this).html() == 'edit' ? 'modify' : 'edit');
    });
});
*/
</script>
 <body>

 
<div class="wrapper">
<h2> Teacher Name here </h2>
<form id="searchForm">
<fieldset>
      <legend>Search student </legend>
      <span><p>Search by Name: <input id="studId" name="id" type="text"> or <input value="Search all students" onclick="" id="btnSearch" class="button" type="button"> </p></span>
	  <p>Search by ID: <input id="studId" name="id" type="text"></p>
	  
	  <input value="Search" onclick="" id="btnSearch" class="button" type="button"> 
	  <input value="Clear" onclick="" id="btnSearch" class="button" type="button"> 
</fieldset>

<h4> Add a Student </h4>
    <fieldset>
      <legend>Student Records </legend>
      <p>Student ID <input id="studId" name="id" type="text"></p>
      <p><span id="orgLabel">First Name</span> <input id="orgName" name="name" type="text"></p>
      <p>Last Name <input id="lastName" name="name" type="text">

	  
      </select> <span id="orgCitySearch"></span></p>
      <p>Course ID <input id="course" name="course" type="text"></p>
      <p>Advisor ID (optional) <input id="advisor" name="zip" type="text"></p>
	  <p>Advisor Name <input id="advisor" name="zip" type="text"></p>
	  <p>Date of Birth <input id="advisor" name="zip" type="text"></p>
	  
	  <input value="Add" onclick="" id="btnSearch" class="button" type="button"> 
    </fieldset>
	
  </form>

  </div>
  
 //temporary div name, can change it to be UNIQUE and use different STYLE
 <div class="wrapper">
 
 
  <?php
	//484/784 LBE13 PHP ODBC
	$url = "Records";
	$user = "admin";
	$passwd = "";
	
	$conn = ODBC_CONNECT($url, $user, $passwd);
	if(!$conn){
		echo ODBC_errormsg();
	}
	else{
		echo "DB connection OK...<br>";
	}
	//It is working
	$sql = "SELECT sc.StudentID, st.LastName, st.FirstName, st.GradeReportID FROM StuCourse sc inner join Student st on sc.StudentID = st.StudentID";
	//$sql = "SELECT * FROM stuCourse inner join courses on stucourse.courseID_FK = courses.courseID inner join student on stuCourse.studentID_FK = student.studentID";
//	inner join courses on student.studentID = stuCourse.studentID_FK and courses.courseID = stuCourse.courseID_FK";
	$sql2 = "Select cs.CourseName, cs.Credits from StuCourse2 sc2 INNER JOIN Courses cs ON sc2.CourseID = cs.CourseID";
	
	$rs = ODBC_EXEC($conn, $sql2);
	
	if(!$rs){	
		echo ODBC_errormsg();
	}
	else{
		echo "<br>";
		echo " This is Table with Courses and Credits";
	}
	
	$rows = ODBC_num_rows($rs);
	$cols = ODBC_num_fields($rs);
	
	

	
	//move cursor back to the top (at the end now)
	ODBC_FETCH_ROW($rs, 0);
	ODBC_RESULT_ALL($rs);
	
	$rs = ODBC_EXEC($conn, $sql);
	
	if(!$rs){	
		echo ODBC_errormsg();
	}
	else{
		echo "<br>";
		echo " Student Info";
	}
	
	$rows = ODBC_num_rows($rs);
	$cols = ODBC_num_fields($rs);
	
	
	echo "<br>";

	echo "<br>";
	
	//move cursor back to the top (at the end now)
	ODBC_FETCH_ROW($rs, 0);
	ODBC_RESULT_ALL($rs);
	
	
	
	ODBC_FREE_RESULT($rs);
	ODBC_CLOSE($conn);
	
	
  ?>
  </div>
  
</body>
</html>
