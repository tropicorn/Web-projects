<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <link rel="stylesheet" type="text/css" href="Css.css">
  <title>Quang's 340 jQuery Project</title>

 </head>
 
 
 <body>
	<h1> Forgot Password </h1>

	<h3> We forgot password sometimes.... more text here </h2>

	<div id="form">
      <fieldset>
      <p>User name <input id="studId" name="id" type="text"></p>
      <p>Email Address <input id="lastName" name="name" type="text"></p>
	  
	  <div id="captcha">
	  Implement Captcha
	  </div>
	  
	  <input value="Submit" onclick="" id="btnSearch" class="button" type="button"> 
	 </fieldset>
	 </div>
	 
	
  
</body>
</html>
