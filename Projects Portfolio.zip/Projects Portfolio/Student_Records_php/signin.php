<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <link rel="stylesheet" type="text/css" href="Css.css">
   <title>High School Student Records</title>

 </head>
 
 
 <body>
	<div class="wrapper">
	<h1> Welcome </h1>
	
	<h2>  Welcome back to our student portal, please Sign In! </h2>
	
	 <fieldset>
      <p>User name 	<input name="id" type="text"></p>
      <p>Password/TA Code <input name="name" type="password"></p>
	  
	  <input value="Login" onclick="" id="btnSearch" class="button" type="button"> 
	  <input value="Forgot Password" onclick="" id="btnSearch" class="button" type="button"> 
	 </fieldset>
	</div>
  
</body>
</html>
