<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <link rel="stylesheet" type="text/css" href="Css.css">
   <title>High School Student Records</title>

 </head>
 
 
 <body>

<form id="searchForm">
    <fieldset>
      <legend>Student Name (get from database dynamically)</legend>
      <table id="records" border="1" width="100%"><tr><th>Course ID:</th>
	  <th>Title:</th><th>Department:</th><th>Teacher:</th><tr></table>
    </fieldset>
  </form>
  
  
</body>
</html>
