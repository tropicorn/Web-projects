/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.compdev.vo;

/**
 *
 * @author PraveenAdivi
 */
public class Phlebotomist {
private String  phlebotomistId;
private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhlebotomistId() {
        return phlebotomistId;
    }

    public void setPhlebotomistId(String phlebotomistId) {
        this.phlebotomistId = phlebotomistId;
    }

}
