/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.compdev.vo;

/**
 *
 * @author PraveenAdivi
 */
public class PatientServiceCenter {
    private String pscName;
    private String pscId;

    public String getPscId() {
        return pscId;
    }

    public void setPscId(String pscId) {
        this.pscId = pscId;
    }

    public String getPscName() {
        return pscName;
    }

    public void setPscName(String pscName) {
        this.pscName = pscName;
    }
}
