/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.compdev.vo;

/**
 *
 * @author PraveenAdivi
 */
public class Physician {
    private String name;
    private int physicianId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPhysicianId() {
        return physicianId;
    }

    public void setPhysicianId(int physicianId) {
        this.physicianId = physicianId;
    }
}
