/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.compdev.exceptions;

/**
 *
 * @author PraveenAdivi
 */
public class DatabaseException extends LAMSException{

public DatabaseException(String args)
{
super(args);

}
}
