import java.io.*;
import java.net.*;

public class WinMessage extends Message implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String playerBMessage;
	private String playerAMessage;
	
	public WinMessage(String ID, String playerA, String playerB)
	{
		super(ID);
		playerAMessage = playerA;
		playerBMessage = playerB;
		
	}
	
	public String getPlayerAMessage()
	{
		return playerAMessage;
	}
	
	public String getPlayerBMessage()
	{
		return playerBMessage;
	}
	
}