
public interface Parameters 
{
	public int chatPort = 16789;
}
