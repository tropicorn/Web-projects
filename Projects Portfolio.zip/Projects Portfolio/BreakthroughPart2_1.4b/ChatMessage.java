import java.io.*;
import java.net.*;

public class ChatMessage extends Message implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String clientName;
	private String message;
	
	public ChatMessage(String gameID, String _name, String _message)
	{
		super(gameID);
		clientName = _name;
		message = _message;
	}
	
	public String toString()
	{
		return clientName + ": " + message;
	
	}
	
}