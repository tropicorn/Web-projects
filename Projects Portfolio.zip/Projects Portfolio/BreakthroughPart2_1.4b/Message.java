import java.io.*;
import java.net.*;

public class Message implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String gameID;

	public Message(String _id)
	{
		gameID = _id;
	}
	
	public String getID()
	{
		return gameID;
	}

}