import java.io.*;
import java.net.*;

public class MoveMessage extends Message implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String Pos1Type; //previous position
	private String Pos2Type; //new position. Does each button have a string assigned?
	private int Pos1x;	//previous x
	private int Pos1y;	//previous y
	private int Pos2x;	//new x
	private int Pos2y;	//new y
	
	public MoveMessage(String ID, String type1, String type2, int onex,
	int oney, int twox, int twoy)
	{
		super(ID);
		Pos1Type = type1;
		Pos2Type = type2;
		Pos1x = onex;
		Pos1y = oney;
		Pos2x = twox;
		Pos2y = twoy;
	}
	
	public int getOldX()
	{
		return Pos1x;
	}
	public int getNewX()
	{
		return Pos2x;
	}
	public int getNewY()
	{
		return Pos2y;
	}
	public int getOldY()
	{
		return Pos1y;
	}
	public String getType1()
	{
		return Pos1Type;
	}
	public String getType2()
	{
		return Pos2Type;
	}
	
	
	
}