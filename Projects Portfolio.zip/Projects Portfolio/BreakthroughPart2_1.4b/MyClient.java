import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
	4002-219 BreakThrough Client
	This is the client with GUI to send and receive messages
	between other  clients

	Channel 4 News Team:
	Rick Skanron
	David Aman
	Rohan Reen
	Quang Nguyen
	Tim Wong
 */

public class MyClient implements Parameters																	
{			
	private static ObjectOutputStream oos;
	private static ObjectInputStream ois;
	private Socket gameSocket;
	private boolean quit = false;

	//private BreakThrough bt;

	//Components for GUI
	//Board Components
	private JFrame jf;
	private JButton [][] buttons;
	private ImageIcon blackChecker ;
	private ImageIcon redChecker ;
	private ImageIcon noChecker;
	private final static Color BG_COLOR1  = new Color(255,255,255);
	private final static Color BG_COLOR2  = new Color(59,67,80);

	//Chat Components
	private JTextArea textArea;
	private JTextField jtfMessage;
	private JButton jbSend;

	//Move Components
	private JButton jbPressed = null;
	private JButton jbReleased = null;
	private JButton jbMoved = null;
	private Icon iconPressed = null;
	private Icon iconReleased = null;

	//Variables for Chat
	private String gameID;
	private String clientName;
	private String host = "129.21.25.37";

	//Variable for Moves
	private MoveMessage mMess;
	private String moveFrom;
	private String moveTo;
	private int moveX;
	private int moveY;
	private int pressX;
	private int pressY;

	public MyClient()
	{
		this.BreakthroughGUI();
		clientName = JOptionPane.showInputDialog(new JFrame(), "Enter name");
		host = JOptionPane.showInputDialog(new JFrame(), "Enter host");
		Communicator com = new Communicator();
		jbSend.addActionListener(com);
		jtfMessage.addActionListener(com);

		try
		{																						
			// These two lines show how to get the IP address of this client			
			System.out.println("getLocalHost:  "+InetAddress.getLocalHost() );			
			System.out.println("getByName:     "+InetAddress.getByName("localhost"));

			// Connect to server's chat port												
			gameSocket = new Socket(host, /*chatPort*/16789);

			// Open inputs from server													
			ois = new ObjectInputStream(gameSocket.getInputStream());	

			// open outputs to server																
			oos = new ObjectOutputStream(gameSocket.getOutputStream());											

			ThreadClient thClient = new ThreadClient();

			thClient.start();

			while(!quit)
			{
				//Sleep 50ms to reduce cpu strain
				Thread.sleep(50);
			}		
			ois.close();
			oos.close();
			gameSocket.close();	
		}
		catch (ConnectException ce){
			JOptionPane.showMessageDialog(new JFrame(), "The connection was refused! Check if the server is correct.");
			System.exit(1);
		}
		catch(UnknownHostException uhe) 
		{														
			System.out.println("no host");														
			uhe.printStackTrace();																
		}																									
		catch(IOException ioe) 
		{																	
			System.out.println("IO error in socket");														
			ioe.printStackTrace();																	
		}																									
		catch( ArrayIndexOutOfBoundsException aioobe ) 
		{									
			System.out.println("\nUsage: java Day10Server hostname some-word");	 	
		} 
		catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
	}

	/**
	 * Assigns the default values and creates GUI 
	 *
	 */

	public void BreakthroughGUI()
	{
		//Creates GUI

		jf = new JFrame();
		buttons = new JButton[8][8];
		jf.setBackground(Color.orange);
		Cursor handCursor = new Cursor(Cursor.HAND_CURSOR);
		jf.setCursor(handCursor);
		JPanel jp = new JPanel(new GridLayout(8,8));
		jf.setTitle("BreakThrough Game");
		jf.setSize(750,550);
		jf.setLocation(100,100);
		blackChecker = new ImageIcon("checker1.gif");
		redChecker = new ImageIcon("checker2.gif");
		noChecker = new ImageIcon("none");
		MouseListen ml = new MouseListen();
		// put the buttons into 2D array
		for(int i = 0; i<8;i++)
		{
			for(int j =0;j<8;j++)
			{
				// put the icons on buttons
				if(j==0 || j==1 || j==6 || j==7){
					if(j==6 || j==7){
						buttons[i][j] = new JButton(blackChecker);
						buttons[i][j].addMouseMotionListener(ml);
						buttons[i][j].addMouseListener(ml);
					}
					else {
						buttons[i][j] = new JButton(redChecker);
						buttons[i][j].addMouseMotionListener(ml);
						buttons[i][j].addMouseListener(ml);
					}
				}
				else{
					buttons[i][j] = new JButton(noChecker);
					buttons[i][j].addMouseMotionListener(ml);
					buttons[i][j].addMouseListener(ml);
				}
				buttons[i][j].setSize(66,61);

				//SET ACTION COMMAND	- to hold values of button coordinates
				String coordinates = Integer.toString(j) + "," + Integer.toString(i);
				buttons[i][j].setActionCommand(coordinates);

				// set the buttons background colors
				if(i==j){
					buttons[i][j].setBackground(BG_COLOR1);
				}
				else if(j%2!=0 && i%2!=0){
					buttons[i][j].setBackground(BG_COLOR1);
				}
				else if(i%2==0 && j%2==0){
					buttons[i][j].setBackground(BG_COLOR1);
				}
				else{
					buttons[i][j].setBackground(BG_COLOR2);
				}
				// ADD button objects to 2D array
				jp.add(buttons[i][j]);
			}
		}

		//CHAT GUI

		JPanel jpChat =  new JPanel(new BorderLayout());

		//create area for client chat
		JPanel jpChatWindow = new JPanel(new BorderLayout());
		textArea = new JTextArea(20,15);
		jpChatWindow.add(textArea);
		textArea.setEditable(false);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		JScrollPane chatScroll = new JScrollPane(textArea);
		chatScroll.setWheelScrollingEnabled(true);
		jpChatWindow.add(chatScroll);
		JLabel jlChat = new JLabel("Chat Window");
		jlChat.setHorizontalAlignment(0);
		jpChatWindow.add(jlChat, "North");

		//Create chat field and send button
		JPanel jpMessageSend = new JPanel(new FlowLayout());
		jtfMessage = new JTextField(10);
		jbSend = new JButton("Send");
		jpMessageSend.add(jtfMessage);
		jpMessageSend.add(jbSend);

		//add all to JPanel that will go on the side of the game
		// jpChat.add(jpClientList,"North");
		jpChat.add(jpChatWindow);
		jpChat.add(jpMessageSend, "South");

		// MENU

		// file Menu bar
		JMenuBar jmb = new JMenuBar();
		jf.setJMenuBar(jmb);
		jmb.setBackground(new Color(183,191,204));
		// File Menu
		JMenu jmFile = new JMenu("File");
		jmFile.setMnemonic('F');
		jmFile.setBackground(new Color(183,191,204));
		jmb.add(jmFile);
		//File Menu New Game item
		JMenuItem jmiNew = new JMenuItem("New Game");
		jmiNew.setMnemonic('x');
		jmiNew.setBackground(new Color(183,191,204));
		jmFile.add(jmiNew);
		//File Menu Exit item
		JMenuItem jmiExit = new JMenuItem("Exit");
		jmiExit.setMnemonic('x');
		jmiExit.setBackground(new Color(183,191,204));
		jmFile.add(jmiExit);
		// Help Menu
		JMenu jmHelp = new JMenu("Help");
		jmFile.setMnemonic('H');
		jmb.add(jmHelp);
		//Help Menu About item
		JMenuItem jmiAbout = new JMenuItem("About");
		jmiAbout.setMnemonic('A');
		jmiAbout.setBackground(new Color(183,191,204));
		jmHelp.add(jmiAbout);
		//Help Menu How to play item
		JMenuItem jmiPlay = new JMenuItem("How to Play?");
		jmiPlay.setMnemonic('H');
		jmiPlay.setBackground(new Color(183,191,204));
		jmHelp.add(jmiPlay);

		// add action listener to file menu items
		FileListener fl = new FileListener();
		jmiExit.addActionListener(fl);
		jmiAbout.addActionListener(fl);
		jmiPlay.addActionListener(fl);
		jmiNew.addActionListener(fl);

		//add panel to the frame
		jf.add(jp);

		//add chat to right side of frame
		jf.add(jpChat,"East");

		// terminate the program when closing button clicked
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//set resizable false
		//jf.setResizable(false);
		//set visible
		jf.setVisible(true);
	}//End of GUI

	/**
	 * This class creates action listener for menu items and implement action listener
	 */
	class FileListener implements ActionListener
	{
		/**
		 * This method handle action event
		 * @ae Action Event
		 */
		public void actionPerformed(ActionEvent ae)
		{
			String caption =ae.getActionCommand();
			// exit item
			if(caption.equals("Exit"))
			{
				int result = JOptionPane.showConfirmDialog(null,"Do you want to quit the game?","Quit The Game",JOptionPane.YES_NO_OPTION);
				if(result==0)
					System.exit(0);
			} 
			// new game item
			else if(caption.equals("New Game"))
			{
				int result = JOptionPane.showConfirmDialog(null,"Do you want to start a new game?","Start a New Game",JOptionPane.YES_NO_OPTION);
				if(result==0)
				{
					new MyClient();
					jf.setVisible(false);
				}
			} 
			// about item
			else if(caption.equals("About"))
			{
				JOptionPane.showMessageDialog(null,"Mini Project - BreakThrough Game\nReleased Date: 4/5/2012","About Brekthrough", JOptionPane.INFORMATION_MESSAGE);
			}
			// how to play the game and rules
			else if(caption.equals("How to Play?"))
			{
				// create new frames for rules
				JFrame jf = new JFrame("How to play!");
				JPanel panel = new JPanel(new GridLayout(1,1));
				jf.setSize(400,480);
				jf.setLocation(350,125);
				jf.setResizable(false);
				// show the rules in the text file
				JTextArea jta = new JTextArea(10,10);
				jta.setEditable(false);
				jta.setLineWrap(true);
				jta.setWrapStyleWord(true);
				JScrollPane jsp = new JScrollPane(jta);
				panel.add(jsp);
				// READ the rule.txt file and show it into text area
				try
				{
					BufferedReader br = new BufferedReader(new FileReader("rule.txt"));
					StringBuffer sb = new StringBuffer();
					String line = null;
					while((line = br.readLine()) != null) 
					{
						sb.append(line + "\n");
					}
					jta.setText(sb.toString());
				}
				catch(FileNotFoundException fnfe)
				{
					JOptionPane.showMessageDialog(null,"Rule file is not found!");
				}
				catch(IOException ioe)
				{
					//ieo.getMessage();
					JOptionPane.showMessageDialog(null,"Something is wrong with the program!");
				}
				jf.add(panel);
				jf.setVisible(true);
			}
		}
	} // end of file listener

	/**
	 * This class tracks mouse buttons and movement in relation to the GUI
	 * Validates and performs moves according to game rules
	 */
	class MouseListen extends MouseAdapter implements MouseMotionListener
	{
		//MOUSE LISTENER			

		//Dimension dimPressed;
		//Dimension dimMoved;

		//stores the last button that was pressed
		public void mousePressed(MouseEvent mp)
		{
			//find button pressed from action command description
			jbPressed = (JButton) mp.getSource();
			System.out.println("pressed " + jbPressed.getIcon() + " " + jbPressed.getActionCommand());

		}
		//stores which button the mouse has entered last,
		//even after being pressed
		public void mouseEntered(MouseEvent me)
		{
			jbMoved = (JButton) me.getSource();
			//System.out.println("moved to " + jbMoved.getIcon() + " " + jbMoved.getActionCommand());
		}

		public void mouseReleased(MouseEvent mr)
		{
			//the mouse button has been released
			jbReleased = (JButton) mr.getSource();
			//System.out.println("released from " + jbReleased.getIcon() + " " + jbReleased.getActionCommand());
			System.out.println("Released on "+ jbMoved.getActionCommand());
			
			//get the icon pressed
			iconPressed = jbPressed.getIcon();
			// get icon released
			iconReleased = jbMoved.getIcon();

			//what player checker was moved? assign it to moveFrom according to protocol			
			if (iconPressed.equals(redChecker))
			{
				moveFrom = "x";
			}
			else if (iconPressed.equals(blackChecker))
			{
				moveFrom = "o";
			}
			else
			{
				moveFrom = "e";
			}
			
			// what was on the spot that mouse released on? assign to moveFrom according to protocol
			if (iconReleased.equals(redChecker))
			{
				moveTo = "x";
			}
			else if(iconReleased.equals(blackChecker))
			{
				moveTo = "o";
			}
			else
			{
				//if doesn't work make null a string on client and server
				moveTo = "e";
			}
			//parse int coordinates of old position
			pressX = Integer.parseInt(jbReleased.getActionCommand().substring(0,1));
			pressY = Integer.parseInt(jbReleased.getActionCommand().substring(2,3));
			
			//parse int coordinates of new position
			moveX = Integer.parseInt(jbMoved.getActionCommand().substring(0,1));
			moveY = Integer.parseInt(jbMoved.getActionCommand().substring(2,3));

			//Use method sendMove from client to get move object
			
			//	TO DO: SEND MOVE INFORMATION TO SERVER
			MoveMessage mm = new MoveMessage(getClientID(), moveFrom, moveTo, pressX, pressY, moveX, moveY);
			System.out.printf("%s %s %s %d %d %d %d\n", mm.getID(), mm.getType1(), mm.getType2(), mm.getOldX(), mm.getOldY(), mm.getNewX(), mm.getNewY());
			
			try
			{
				System.out.println("Sending: " + mm.toString());
				oos.writeObject(mm);
				oos.flush();
				System.out.println("Sent: " + mm.toString());
			}
			catch(IOException ioe)
			{
				System.out.println("IOException: Message send failed");
			}
			catch(NullPointerException npe)
			{
				System.out.println("NullException: IDFK"); //LOL
				npe.printStackTrace();
			}
			jtfMessage.setText("");

			
		}	
	}

	/**
	 * Still needed?
	 * @return
	 */
	public String getClientID()
	{
		return gameID;
	}

	/**
	 * Method for Client to use to send Move information.
	 * MAY NOT BE NEEDED?
	 * @param ID
	 * @param moveFrom
	 * @param moveTo
	 * @param moveX
	 * @param moveY
	 * @param pressX
	 * @param pressY
	 */
	 
// 	public static void sendMove(String ID, String moveFrom, String moveTo, int pressX, int pressY, int moveX, int moveY)
// 	{
// 		System.out.println("Method being used!");
// 		System.out.printf("%s %s %s %f %f %f %f", ID, moveFrom, moveTo, pressX, pressY, moveX, moveY);
// 		try
// 		{
// 			oos.writeObject(new MoveMessage(ID, moveFrom, moveTo, pressX, pressY, moveX, moveY));
// 			oos.flush();
// 		}
// 
// 		catch(IOException ioe)
// 		{
// 			System.out.print("IO: Problem sending move message to server");
// 		}
// 	}

	class ThreadClient extends Thread 
	{
		public ThreadClient()
		{
			super();
		}

		public void run()
		{
			try
			{
				Message initialMessage = (Message)ois.readObject();
				gameID = initialMessage.getID();
				System.out.println(gameID);
				
				while (true)
				{
					sleep(50);

					//Receive message from server
					Message message = (Message)ois.readObject();

					//Check if message is a chat message
					if(message instanceof ChatMessage)
					{
						ChatMessage cMess = (ChatMessage) message;
						textArea.append(cMess.toString() + "\n");
						System.out.println("Received a chat message >> " + cMess.toString());
					}

					//Check if message is a move message
					else if(message instanceof MoveMessage)
					{
						mMess = (MoveMessage)message;
						System.out.println("MoveMessage read by client");
						System.out.printf("With values %s %s %s %d %d %d %d\n", mMess.getID(), mMess.getType1(), mMess.getType2(), mMess.getOldX(), mMess.getOldY(), mMess.getNewX(), mMess.getNewY());

						moveFrom = mMess.getType1();
						moveTo = mMess.getType2();
						pressX = mMess.getNewX();
						pressY = mMess.getNewY();
						moveX = mMess.getOldX();
						moveY = mMess.getOldY();
						
						
						Icon old = buttons[moveY][moveX].getIcon();
						buttons[moveY][moveX].setIcon(noChecker);
						buttons[pressY][pressX].setIcon(old);
					
					}
					else if(message instanceof WinMessage)
					{
						WinMessage wm = (WinMessage) message;
						String pid = message.getID();
						int IDLength = pid.length();
						char playerLetter = pid.charAt(IDLength-1);
						
						if(playerLetter == 'A')
						{
							JOptionPane.showMessageDialog(null, wm.getPlayerAMessage());
						}
						else
						{
							JOptionPane.showMessageDialog(null, wm.getPlayerBMessage());
						}
					}
				}
			}
			catch(ClassNotFoundException cnfe)
			{
				System.out.println("Unkown object sent from server");
			
			}
			catch(InterruptedException ie)
			{
				System.out.println("Processing of object from server interrupted");
			}
			catch(EOFException eofe)
			{
				System.out.println("End of file exception");
			}
			catch(SocketException se)
			{
				System.out.println("Client has disconnected");
				textArea.append("The server has gone down\n");
			}
			catch(IOException ioe)
			{
				System.out.println("IOException: Error reading object from server");
				ioe.printStackTrace();
			}
		}
	}

	class Communicator implements ActionListener
	{	
		public void actionPerformed(ActionEvent e)
		{
			ChatMessage cm = new ChatMessage(gameID, clientName, jtfMessage.getText());
			try
			{
				System.out.println("Sending: " + cm.toString());
				oos.writeObject( cm );
				oos.flush();
				System.out.println("Sent: " + cm.toString());
			}
			catch(IOException ioe)
			{
				System.out.println("IOException: Message send failed");
				textArea.append("The message could not be sent.");
			}
			jtfMessage.setText("");
		}
	}

	/**
	 * This main method runs the BreakThrough game 
	 * @args the string array
	 */
	public static void main(String args[])
	{
		new MyClient();
	}
}
