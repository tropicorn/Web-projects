import java.awt.BorderLayout;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.BindException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;
import java.awt.*;

import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;



/**
	4002-219 BreakThrough Server
	This is the server for the MyClient class/GUI

	Channel 4 News Team:
	Rick Skanron
	David Aman
	Rohan Reen
	Quang Nguyen
	Tim Wong
 */

public class MyMultiThreadedServer implements Parameters
{
	private Vector <ThreadServer> connectedClients = new Vector <ThreadServer>();
	private Vector <Game> games = new Vector<Game>();
	//private Vector <ThreadListServer> thConnected = new Vector<ThreadListServer>();

	private int count = 0;
	//added playerCount to make valid IDs
	private int playerCount = 0;
	private int numGames = 0;
	private ServerSocket chatS = null;

	//GUI components
	private ServerGUI serverGUI; 
	//	private JFrame frame;
	//	private JTextArea jtaInfo;

	/**
	 * Default constructor
	 */
	public MyMultiThreadedServer() 
	{	

		//createGUI();
		serverGUI = new ServerGUI();

		try {
			chatS = new ServerSocket(chatPort);
			System.out.println("getLocalHost: "+InetAddress.getLocalHost() );
			System.out.println("getByName:    "+InetAddress.getByName("localhost") );

			while(true){ 		// run until server is shut down
				//Sleep 50ms to reduce cpu strain
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				Socket clientChatSocket = chatS.accept(); // wait for 1st client to connect
				count++;
				ThreadServer ths1 = new ThreadServer(clientChatSocket);
				connectedClients.add(ths1);
				ths1.start();
				
				if(connectedClients.size() % 2 == 1)
				{
					playerCount++;
				}

				clientChatSocket = chatS.accept();	//wait for 2nd client to connect
				count++;
				ThreadServer ths2 = new ThreadServer(clientChatSocket);
				connectedClients.add(ths2);
				ths2.start();
				
				if(connectedClients.size() % 2 == 1)
				{
					playerCount++;
				}
				
				//Sleep another 50ms to allow ThreadServer to instantiate and Game to recognize second player
				try
				{
					Thread.sleep(50);
				}
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
				numGames++;
				Game game = new Game(ths1, ths2);
				games.add(game);

				System.out.println("Game has started");
				refreshGamesList();


			} // end while
		}
		catch( BindException be ) {
			System.out.println("Server already running on this computer, stopping.");
			System.exit(1);
		}
		//catch(InterruptedException ie){}
		catch( IOException ioe ) {
			System.out.println("IO Error");
			ioe.printStackTrace();
		}

	} // end main

	/**
	 * Main method for the MyMultiThreadedServer class
	 * @param args
	 */
	public static void main(String [] args)
	{
		new MyMultiThreadedServer();
	}

	/**
	 * Appends text to the chatbox
	 * @param chatBox
	 * @param text
	 */
	public void appendToInfoArea(JTextArea chatBox, String text) {
		chatBox.append(text);
	}

	/**
	 * Refreshes list of connected clients in server GUI whenever a client (dis)connects
	 */
	public synchronized void refreshClientsList()
	{
		//System.out.println(connectedClients.size());
		serverGUI.getJtaWest().setText("");
		serverGUI.appendJTAWest(connectedClients.size() + " client(s) connected! \n");
		if (connectedClients.size() < 1)
		{
			//do nothing
			System.out.println("Not refreshing");
		}
		else
		{
			for (int x = 0; x < connectedClients.size(); x++)
			{
				//System.out.println("refreshing");
				serverGUI.appendJTAWest("Client ID: " + connectedClients.get(x).getClientID() + "\n");
			}
		}
	}

	/**
	 * Refreshes list of gmaes in server GUI whenever a game starts/ends
	 */
	public synchronized void refreshGamesList()
	{
		//System.out.println(connectedClients.size());
		serverGUI.getJtaCenter().setText("");
		serverGUI.appendJTACenter(games.size() + " games running! \n");
		if (games.size() < 1)
		{
			//do nothing
			System.out.println("Not refreshing");
		}
		else
		{
			for (int x = 0; x < games.size(); x++)
			{
				//System.out.println("refreshing");
				serverGUI.appendJTACenter("Game ID: " + games.get(x).getGameID() + "\n");
			}
		}
	}

	/**
	 * Class that represents a game
	 */
	public class Game
	{
		private boolean player1Turn;
		private ObjectOutputStream player1out, player2out;
		private String gameID;

		public Game(ThreadServer player1, ThreadServer player2){
			player1out = player1.getClientObjectOutStream();
			player2out = player2.getClientObjectOutStream();
			this.gameID = Integer.toString(numGames);
			player1.setGameID(gameID);
			player2.setGameID(gameID);
			try 
			{
				player1out.writeObject(new ChatMessage(player1.getClientID(), "Server", "You are now in game " + this.getGameID() + "!\n" +
						"Your opponent is "+ player2.getClientID() + "\n" +
						"You are Player 1, Red"));
				player1out.flush();
				player2out.writeObject(new ChatMessage(player2.getClientID(), "Server", "You are now in game " + this.getGameID() + "!\n" +
						"Your opponent is "+ player1.getClientID() + "\n" +
						"You are Player 2, Black"));
				player2out.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
			player1Turn = true;
		}

		public String getGameID(){
			return gameID;
		}
		
		public boolean getPlayer1Turn()
		{
			return player1Turn;
		}
		
		public synchronized void validateMove(MoveMessage mMess, String playerID)
		{
			String moveFrom = mMess.getType1();
			String moveTo = mMess.getType2();
			int startX = mMess.getOldX();
			int startY = mMess.getOldY();
			int endX = mMess.getNewX();
			int endY = mMess.getNewY();
			String pid = playerID;
			int IDLength = playerID.length();
			char playerLetter = pid.charAt(IDLength-1);
			
			System.out.println(moveFrom);
			System.out.println(moveTo);
			System.out.println(startX + " " + startY + " " + endX + " " + endY);
			
			
			//if player ID ends with A and it isn't player 1's turn
		 	if( playerLetter == 'A' && !player1Turn )
			{
				System.out.println("Player 1 tried to move player 2! Move aborted");
				
			}
			else if(playerLetter == 'B' && player1Turn )
			{
				System.out.println("Player 2 tried to move player 1! Move aborted");
			}
			//if pressed empty square, or move was to same type of checker
			// if(jbPressed.getIcon().equals(noChecker) || jbPressed.getIcon() == jbMoved.getIcon())
			else if(moveFrom.equals("e") || ((startX == endX) && (startY == endY)) || moveFrom.equals(moveTo) )
			{
				System.out.println("Move was from blank or tried taking over same type");
				//tell client to try again
			} 
			//if pressed wrong icon for turn, no move
			// else if( (redsTurn == true && jbPressed.getIcon().equals(blackChecker)) || (redsTurn == false && jbPressed.getIcon().equals(redChecker))
			else if( ( player1Turn && moveFrom.equals("o") ) || ( !player1Turn && moveFrom.equals("x") ) )		
			{
				System.out.println("Wrong turn");
				//tell client to try again
			}
			//Move is not forward for checker 
			// else if( (redsTurn && (moveX <= pressX) || (!redsTurn && moveX >= pressX)) )	
			else if( (player1Turn && (endX <= startX) || (!player1Turn && endX >= startX)) )
			{
				System.out.println("Must move forward: X attempted from " + startX + " to " + endX);
				//tell client to try again
			}
			//Move is more than one space away in any direction
			else if(( Math.abs(endY - startY) > 1) || ( Math.abs(endX - startX) > 1)) 
			{
				System.out.println("Can only move one space");
				//tell client to try again
			}
			//trying to capture by moving forward 
			// else if( jbMoved.getIcon() != noChecker && ((moveY-pressY) == 0 && jbPressed.getIcon() != jbMoved.getIcon()) )
			else if( !moveTo.equals("e") && ((endY-startY) == 0 && moveFrom != moveTo)) 
			{
				System.out.println("Bad Move: can't capture moving forward");
				//tell client to try again
			}

			//do move!
			else 
			{
				System.out.println("Move has validated.");

				try {
					player1out.writeObject(mMess);
					player1out.flush();
					player2out.writeObject(mMess);
					player2out.flush();
				} catch (IOException e) {
					e.printStackTrace();
				}

				//if the checker reaches the other side
				//int result = 1;
				if( (moveFrom.equals("x") && endX == 7) || (moveFrom.equals("o") && endX == 0) )
				{
					//say who won
					if(moveFrom.equals("x"))
					{
						System.out.println("Player 1 wins");
						
						try
						{
							//send WIN object with player1 being the winner
							player1out.writeObject(new WinMessage(playerID, "You Won the game!", "You Lost"));
							player1out.flush();
							player1out.close();
							
							player2out.writeObject(new WinMessage(playerID, "You Won the game!", "You Lost"));
							player2out.flush();
							player2out.close();
						}
						
						catch(IOException io) {}
					}
					else
					{
						System.out.println("Player 2 wins");
						//send WIN object wth player2 being the winner
						
						try
						{
							//send WIN object with player2 being the winner
							player1out.writeObject(new WinMessage(playerID, "You Lost", "You Won the game!" ));
							player1out.flush();
							player1out.close();
							
							player2out.writeObject(new WinMessage(playerID, "You Lost", "You Won the game!"));
							player2out.flush();
							player2out.close();

						}
						
						catch(IOException io) {}

					}

				}
				//change turn
				player1Turn = !player1Turn;
			}
		}
	}//end class Game

	/**
	 * GUI class for the server GUI
	 */
	public class ServerGUI extends JFrame{
		//private static final long serialVersionUID = 1L;
		private JTextArea jtaWest, jtaCenter, jtaSouth;
		private JScrollPane jspWest, jspCenter, jspSouth;
		public ServerGUI(){
			jtaWest = new JTextArea(10,10);
			jtaCenter = new JTextArea(10,10);
			jtaSouth = new JTextArea(10,20);

			jtaWest.setEditable(false);
			jtaCenter.setEditable(false);
			jtaSouth.setEditable(false);

			jspWest = new JScrollPane(jtaWest);
			jspCenter = new JScrollPane(jtaCenter);
			jspSouth = new JScrollPane(jtaSouth);

			setLayout(new BorderLayout());

			add(jspWest, "West");
			add(jspCenter, "Center");
			add(jspSouth, "South");

			setSize(400,400);
			setDefaultCloseOperation(EXIT_ON_CLOSE);
			setVisible(true);
		}
		/**
		 * Getter for the west panel
		 * @return jtaWest
		 */
		public JTextArea getJtaWest() {
			return jtaWest;
		}
		/**
		 * Append method for west panel
		 * @param message
		 */
		public synchronized void appendJTAWest(String message) {
			jtaWest.append(message);
		}
		/**
		 * Getter for center panel
		 * @return jtaCenter
		 */
		public JTextArea getJtaCenter() {
			return jtaCenter;
		}
		/**
		 * Append method for center panel
		 * @param message
		 */
		public synchronized void appendJTACenter(String message) {
			jtaCenter.append(message);
		}
		/**
		 * Getter for south panel
		 * @return jtaSouth
		 */
		public JTextArea getJtaSouth() {
			return jtaSouth;
		}
		/**
		 * Append method for south panel
		 * @param message
		 */
		public synchronized void appendJTASouth(String message) {
			jtaSouth.append(message);
		}

	}

	/**
	 * Thread class that represents a connected client and handles all server-client communications 
	 */
	public class ThreadServer extends Thread {
		//Sockets for this specific thread
		//private Socket clientChatSocket;

		private ObjectInputStream ois;		
		private ObjectOutputStream oos;

		private String clientID; //ID of client
		private String gameID; //ID of game that client is in

		private int clientsConnected;

		/**
		 * Parameterized constructor
		 * @param clientChatSocket
		 */
		public ThreadServer(Socket clientChatSocket) {
			//this.clientChatSocket = clientChatSocket;
			clientsConnected = connectedClients.size();

			try {
				oos = new ObjectOutputStream(clientChatSocket.getOutputStream());
				ois = new ObjectInputStream(clientChatSocket.getInputStream());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		/**
		 * Getter for clientID
		 * @return clientID
		 */
		public String getClientID()
		{
			return clientID;
		}

		/**
		 * Returns object output stream of client
		 * @return oos
		 */
		public ObjectOutputStream getClientObjectOutStream(){
			return oos;
		}

		/**
		 * Returns gameID of game that client is in
		 * @return gameID
		 */
		public String getGameID() {
			return gameID;
		}

		/**
		 * Sets gameID when game is initiated
		 * @param gameID
		 */
		public void setGameID(String gameID) 
		{
			this.gameID = gameID;
		}

		/**
		 * Run method of thread
		 */
		public void run() 
		{
			try 
			{	
				boolean sentInitialMessage = false;

				while(true)
				{	
					//make sure to send initial package
					if(!sentInitialMessage)
					{
						//tell client what their ID is, which is the next number in count

						if(connectedClients.size() % 2 == 1/*connectedClients.size() < 10*/)
						{
							clientID = playerCount + "A";
						}

						else 
						{
							clientID = playerCount + "B";
						}
						
						oos.writeObject(new Message(clientID));
						oos.flush();
						oos.writeObject(new ChatMessage(clientID, "Server", " Welcome to the Chat!"));
						oos.flush();
						sentInitialMessage = true;
					}
					//check for activity every 50ms to reduce CPU strain
					try 
					{
						sleep(50);
					} catch (InterruptedException e) 
					{
						e.printStackTrace();
					}
					//check if # of connected clients known by client equals the current # of connected clients
					if (clientsConnected != connectedClients.size()){
						clientsConnected = connectedClients.size();
						serverGUI.appendJTASouth(clientID + " has connected! \n");
						refreshClientsList();
					}

					//Receive message from client
					Message message = (Message)ois.readObject();
					System.out.println("Read Object");

					//Check if message is a chat message
					if(message instanceof ChatMessage)
					{
						System.out.println("ChatMessage received");
						ChatMessage cMess = (ChatMessage)message;
						serverGUI.appendJTASouth(message.toString() + "\n");

						//Broadcast the message to all connected clients
						for(int i = 0; i < connectedClients.size(); i++)
						{
							//get output stream for the selected client in vector  
							ObjectOutputStream tempOut = connectedClients.get(i).getClientObjectOutStream();

							//set oos to client's socket
							// oos = new ObjectOutputStream(tempClientSock.getOutputStream());

							tempOut.writeObject(cMess);	//to client
							//System.out.println("Server Sent to client number " + i + ": " + clientMsg);
							tempOut.flush();
						}
					}

					//Check if message is a move message
					else if(message instanceof MoveMessage)
					{
						MoveMessage mMess = (MoveMessage)message;
						System.out.println("It is a Move object");
						for (Game g: games)
						{
							if (g.getGameID().equals(this.getGameID()))
							{
								System.out.println(clientID);
								g.validateMove(mMess, clientID);
							}
						}
					}//end else if
					
					else
					{
						WinMessage wMess = (WinMessage)message;
						
						for(int i = 0; i <= playerCount; i++)
						{
						
							ObjectOutputStream oOut = connectedClients.get(i).getClientObjectOutStream();
							
							oOut.writeObject(wMess); //send win object to client
							oOut.flush();
						}

					
					}
					
				}//end while				
			}
			catch( IOException e ) { 
				System.out.println("Inside catch, connection may have been lost"); 
				connectedClients.remove(this);
				serverGUI.appendJTASouth(clientID + " has disconnected! \n");
				for(int i = 0; i < connectedClients.size(); i++)
				{
					//get output stream for the selected client in vector  
					ObjectOutputStream tempOut = connectedClients.get(i).getClientObjectOutStream();
					try {
						tempOut.writeObject(new ChatMessage(clientID, "Server", clientID + " has disconnected! \n"));
						tempOut.flush();
					} catch (IOException e1) {
						e1.printStackTrace();
					}	//to client
					for (Game g: games){
						if (this.getGameID() == g.getGameID()){
							try {
								tempOut.writeObject(new ChatMessage(clientID, "Server", "Your game has ended."));
								tempOut.flush();
							} catch (IOException e1) {
								e1.printStackTrace();
							}
							games.remove(g);
							refreshGamesList();
							break;
						}

					}
					//System.out.println("Server Sent to client number " + i + ": " + clientMsg);
				}//end for loop
				refreshClientsList();
				//thConnected.remove(this);
				//updateList();
				//	e.printStackTrace();
			}

			catch(ClassNotFoundException cnf) {
				cnf.printStackTrace();
			}

		} // end run

	} // end class ThreadServer 

} // end MyMultiThreadedServer