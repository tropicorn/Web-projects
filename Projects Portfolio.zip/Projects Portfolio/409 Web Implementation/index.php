<!DOCTYPE html>
<html>
	
	<head>
		
		<meta charset="utf-8" />
		<title>4002.409 Website Design and Implementation</title>
		
		<link rel="stylesheet" href="styleFinal.css" type="text/css">
		<link rel="stylesheet" href="carousel/nivo-slider.css" type="text/css" media="screen" />
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
		<script src="carousel/jquery.nivo.slider.pack.js" type="text/javascript"></script>
	</head>
	
	<body>
		
		<?php
			include("mainNav.inc.html");
		?>		

		
		<div id="sub">
		<h1>Welcome to 4002.409</h1>
		

		<p>Welcome to the 4002.409 home page. This is where you can find all of your course work, lecture notes, and information regarding office hours.</p>

		</div>

		<div id="content">
	
		<h1> Course Description </h1>
		
		<p> This course builds on the basic aspects of HTML, Web design, 
		and multimedia programming that are presented in 320/741 (the prerequisites to this course). </p>
		<p>It provides an overview of Web design concepts, including usability, accessibility, information design, 
		and graphic design in the context of the Web. It also provides an introduction to important 
		and emerging Web site technologies.</p>

		</div>
		
		<div id="previous">
		
		<h1> Previous Works </h1>

		</div>
		
		<div class="slider-wrapper">
			<div id="slider" class="nivoSlider">
				<img src="carousel/andy.png" alt="Andy DiStasi's Web Page" />
				<img src="carousel/michaela.png" alt="Michaela Butler's Web Page" />
				<img src="carousel/quang.png" alt="Quang Nguyen's Web Page" />
				<img src="carousel/sandy.png" alt="Sandy Nadal's Web Page" />
				<img src="carousel/nasser.png" alt="Nasser Allheeib's Web Page" />
			</div>
		</div>

		<?php
			include("footer.inc.html");
		?>
		
		<script type="text/javascript">
			$(window).load(function() {
				$('#slider').nivoSlider();
			});
		</script>
	</body>
	
</html>