<!DOCTYPE html">
<html>

	<head>
	
		<meta charset="utf-8" />
		<title>409 Contact</title>
		
		<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	
	</head>
	
	<body>
		
		<?php
			include("../mainNav.inc.html");
		?>

		<div class="banner">
		Banner here
		</div>

		
		<br>

		<div id="sub">
			<h1>Sean Sims</h1>
			<span id="photo">
				<img src="images/SSims.jpg" border="2" width="150px" alt="Photo of Sean Sims"><br />
		
			</span>
		</div>

		<div id="content">
			<h1> Contact Information </h1>
			
				<b>Phone:</b> (585) 475-7655<br>
				<b>E-mail:</b> sean.sims@rit.edu<br>
				<b>Office:</b> GOL (70) 2634<br>
				<b>Office Hours:</b>
				<ul>
					<li>Mon/Wed 8-9PM</li>
					<li>Tues/Thurs 12-1PM</li>
					<li>(Other hours available by appointment only)</li>
				</ul>
		</div>
				
		

		<footer> Professor Sims </footer>
	</body>
</html>
