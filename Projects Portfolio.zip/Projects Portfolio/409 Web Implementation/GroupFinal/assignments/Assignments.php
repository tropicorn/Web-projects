<!DOCTYPE html> 
<html>

	<head>
		<meta charset="utf-8" />
		<title>Group</title>
	
	<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	
	</head> 

	<body> 

	<?php
			include("../mainNav.inc.html");
	?>

	<div class="banner">
	Banner here
	</div>
	
	<div id="sub"> 
	<h1> Submenu </h1>

	<?php
		include("../assignmentNav.inc.html");
	?>

	</div>
	
	<div id="content">
		<h1> Assignments</h1>

		 <section id="main">
			
		<h2>ICE</h2>
		<h3>ICE 1 </h3>
		 <P> Go to mycourses and <a  href=" css_ice_starter.zip">download </a> DHTML Exercise Starter File. Use JavaScript to do this. </P>

		
			<h3>ICE 2 </h3>
		<P>  <a  href=" css_ice_starter.zip">Download </a>  CSS Exercise Starter File. Follow the instructions</P>
		

			<h3>ICE 3 </h3>
		<P>  <a  href=" jQuery.zip">Download </a> this file and follow the instructions</P>

			<h3>ICE 4 </h3>
			<P> <a  href=" jQuery Carousel Exercise.zip">Download </a> jQuery Carousel Exercise  File and follow the instructions</P>

			
			<h3>ICE 5 </h3>
	<p>  <a  href="nav_example.zip">Download </a> HTML5/CSS3 Dropdown Navigation Menu Exercise and follow the instructions </p>

			<h3>ICE 6 </h3>
	<p>  <a  href="HTML Forms ICE.zip">Download </a> HTML Forms ICE and follow the instructions </p>

			<h3>ICE 7 </h3>
	<p>  <a  href="Database ICE.zip">Download </a>Database ICE file  and follow the instructions </p>
			
			<h2>HW</h2>
					  
				 <p>It is the projects </p>
				 
			
		 </section>

	</div>
	
		
		<footer> Professor Sims </footer>
	</body>
	
</html>