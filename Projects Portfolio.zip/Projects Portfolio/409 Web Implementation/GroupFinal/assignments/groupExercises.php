<!DOCTYPE html>

<html>
<head>

    	<meta charset="utf-8" />
   	<title> Group Exercise </title>
 	
	<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	
	</head> 

	<body> 

	<?php
			include("../mainNav.inc.html");
	?>

	<div class="banner">
	Banner here
	</div>
	
	<div id="sub"> 
	<h1> Submenu </h1>

	<?php
		include("../assignmentNav.inc.html");
	?>

	</div>
	
	<div id="content">
		
		<h2>Group Exercise</h2>
		
		<ul>
			<li>Activity 1 </li>
		</ul>
		
		<p>&nbsp; Make brainstorm about Master List of possibilities</p>
		
		<ul>
			<li>Activity 2 </li>
		</ul>
		
		<p> &nbsp; Choose two of your favourite recipes and build a webpage supported with images.</p>
		
	</div>
	
	
		<footer> Professor Sims </footer>

	</body>
	
</html>