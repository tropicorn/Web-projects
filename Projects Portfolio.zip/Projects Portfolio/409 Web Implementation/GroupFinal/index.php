<!DOCTYPE html>
<html>
	
	<head>
		
		<meta charset="utf-8" />
		<title>4002.409 Website Design and Implementation</title>
		
		<link rel="stylesheet" href="styleFinal.css" type="text/css">
	</head>
	
	<body>
		
		<?php
			include("mainNav.inc.html");
		?>		
		
		<div id="carousel">
		<p> Carousel here </p>
		</div>

		<div id="sub">
		<h1>Welcome to 4002.409</h1>
		

		<p>Welcome to the 4002.409 home page. This is where you can find all of your course work, lecture notes, and information regarding office hours.</p>

		</div>

		<div id="content">
	
		<h1> Course Description </h1>
		
		<p> This course builds on the basic aspects of HTML, Web design, 
		and multimedia programming that are presented in 320/741 (the prerequisites to this course). </p>
		<p>It provides an overview of Web design concepts, including usability, accessibility, information design, 
		and graphic design in the context of the Web. It also provides an introduction to important 
		and emerging Web site technologies.</p>

		</div>

		<div id="previous">
		
		<h1> Previous Works </h1>

		</div>

		<footer>Professor Sims</footer>
		
	</body>
	
</html>