<!DOCTYPE html>    
<html lang="en">
	<head>
	
		<meta charset="utf-8" />
		<title>409 Group 4 Final</title>
		
	<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	
	</head> 

	<body> 

	<?php
			include("../mainNav.inc.html");
	?>

	<div class="banner">
	Banner here
	</div>
	
	<div id="sub"> 
	<h1> Submenu </h1>
	
	<?php
		include("../lecturesNav.inc.html");
	?>

	</div>
	
	<div id="content">
		<h1>Week 3</h1>
			<h2>Lectures</h2>
				<ul>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week03/lecture.html">Lecture</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week03/javascript.html">Javascript</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week03/javascriptEmail.html">Javascript Email</a><li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week03/interaction.html">Interaction</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week03/pseudoAnchors.html">Pseudo Anchor</a></li>
				</ul>
				
			<h2>Examples</h2>
				<ul>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week03/positioningTest.html">positioningText</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week03/iframes/iframeDemo.html">iFrames</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week03/visAnchor.html">visAnchor</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week03/access.html">Access</a></li>
				</ul>
				
			<h2>Readings</h2>
				<ul>
					<li><a href="http://www.build-a-website.net/making-a-website-outline/">Making a Website Online</a></li>
					<li><a href="http://www.bene.be/blog/comments/a_webdesign_brief_document_for_every_website/">A Web Design Brief Document for Every Website</a></li>
				</ul>
	</div>
	<footer> Professor Sims </footer>
	
	</body>

</html>