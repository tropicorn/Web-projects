<!DOCTYPE html>    
<html lang="en">
	<head>
	
		<meta charset="utf-8" />
		<title>409 Group 4 Final</title>
		
	<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	
	</head> 

	<body> 

	<?php
			include("../mainNav.inc.html");
	?>

	<div class="banner">
	Banner here
	</div>
	
	<div id="sub"> 
	<h1> Submenu </h1>
	
	<?php
		include("../lecturesNav.inc.html");
	?>

	</div>
	
	<div id="content">

		<h1>Week 6</h1>
			<h2>Lectures</h2>
				<ul>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week06/index.html">Lecture 6</a></li>
				</ul>
				
			<h2>Examples</h2>
				<ul>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week06/ajax.html">AJAX</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week06/demo.html">Demo</a></li>
					<li><a href="dropdown.html">Dropdown</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week06/nav_example.html">Nav Example</a></li>
				</ul>
				
			<h2>Readings</h2>
				<ul>
					<li><a href="http://www.perl.com/pub/2000/10/begperl1.html">PERL Tutorial</a></li>
					<li><a href="http://www.perlquiz.co.uk/">Take the PERL Quiz</a></li>
					<li><a href="http://www.cpan.org/">Comprehensive PERL Archive Network</a></li>
					<li><a href="http://httpd.apache.org/docs/1.3/howto/ssi.html">SSI Tutorial from Apache</a></li>
					<li><a href="http://www.apache.org/">Apache Software Foundation</a></li>
					<li><a href="http://www.w3.org/WAI/">The Web Accessibility Initiative</a></li>
					<li><a href="http://prototypejs.org/">JavaScript and AJAX framework</a></li>
				</ul>
		
	</div>
	<footer> Professor Sims </footer>
	</body>

</html>