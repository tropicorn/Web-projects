<!DOCTYPE html>    
<html lang="en">
	<head>
	
		<meta charset="utf-8" />
		<title>409 Group 4 Final</title>
		
	<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	
	</head> 

	<body> 

	<?php
			include("../mainNav.inc.html");
	?>

	<div class="banner">
	Banner here
	</div>
	
	<div id="sub"> 
	<h1> Submenu </h1>
	
	<?php
		include("../lecturesNav.inc.html");
	?>

	</div>
	
	<div id="content">
		<h1>Week 4</h1>
			<h2>Lectures</h2>
				<ul>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week04/getElementsByClassName.html">getElementsByClassName</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week04/getByClassNameDemo_01.html">getElementsByClassName Demo1</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week04/getByClassNameDemo_02.html">getElementsByClassName_Demo2.html</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week04/javascript.html">Javascript</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week04/javascriptDOM.html">Javascript DOM</a></li>
				</ul>
				
			<h2>Examples</h2>
				<ul>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week04/dhtml_fun_done.html">DHTML Fun Done</a></li>
				</ul>
				
			<h2>Readings</h2>
				<ul>
					<li><a href="http://www.webmonkey.com/2010/02/mulders_stylesheets_tutorial/">Webmonkey CSS Tutorial</a></li>
					<li><a href="http://www.brainjar.com/css/using/">Using CSS</a></li>
					<li><a href="http://www.webmonkey.com/2010/02/javascript_tutorial/">Webmonkey JS Tutorial</a></li>
					<li><a href="http://www.webteacher.com/javascript/">Web Teacher JS Tutorial</a></li>
					<li><a href="http://www.w3schools.com/js/default.asp">W3Schools Javascript Tutorial</a></li>
					<li><a href="http://en.wikipedia.org/wiki/Comparison_of_web_browsers">Browser Support Chart (Wikipedia)</a></li>
					<li><a href="http://www.webreference.com/dhtml/index.html">DHTML Lab</a></li>
					<li><a href="http://www.w3schools.com/html/html_forms.asp">W3Schools Form Tutorial</a></li>
					<li><a href="http://www.drdobbs.com/the-future-of-forms/184413116">The Future of Forms</a></li>
				</ul>
		
	</div>
	<footer> Professor Sims </footer>
	</body>

</html>