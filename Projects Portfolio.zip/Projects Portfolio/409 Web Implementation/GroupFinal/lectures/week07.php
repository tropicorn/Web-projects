<!DOCTYPE html>    
<html lang="en">
	<head>
	
		<meta charset="utf-8" />
		<title>409 Group 4 Final</title>
		
	<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	
	</head> 

	<body> 

	<?php
			include("../mainNav.inc.html");
	?>

	<div class="banner">
	Banner here
	</div>
	
	<div id="sub"> 
	<h1> Submenu </h1>
	
	<?php
		include("../lecturesNav.inc.html");
	?>

	</div>
	
	<div id="content">
		
		<h1>Week 7</h1>
			<h2>Examples</h2>
				<ul>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week07/slider.html">Slider</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week07/slider_01.html">Slider01</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week07/slider_02.html">Slider02</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week07/slider_03.html">Slider03</a></li>
				</ul>
				
			<h2>Readings</h2>
				<ul>
					<li>Wikipedia article on <a href="http://en.wikipedia.org/wiki/DHTML"></a></li>
					<li>Example of dynamic pages using XHTML, CSS, and JavaScript: <a href="http://meyerweb.com/eric/tools/s5/"></a></li>
					<li><a href="http://www.w3schools.com/jsref/">Document Object reference</a></li>
					<li><a href="http://www.w3schools.com/htmldom/dom_examples.asp">DOM manipulation examples</a></li>
					<li><a href="http://www.w3schools.com/dhtml/dhtml_examples.asp">DOM functions and examples</a></li>
					<li><a href="http://css.maxdesign.com.au/floatutorial/tutorial0801.htm">Float Tutorial</a></li>
				</ul>
		
	</div>
	<footer> Professor Sims </footer>
	</body>

</html>