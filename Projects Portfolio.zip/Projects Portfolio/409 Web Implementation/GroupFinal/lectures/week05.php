<!DOCTYPE html>    
<html lang="en">
	<head>
	
		<meta charset="utf-8" />
		<title>409 Group 4 Final</title>
		
	<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	
	</head> 

	<body> 

	<?php
			include("../mainNav.inc.html");
	?>

	<div class="banner">
	Banner here
	</div>
	
	<div id="sub"> 
	<h1> Submenu </h1>
	
	<?php
		include("../lecturesNav.inc.html");
	?>

	</div>
	
	<div id="content">
		
		<h1>Week 5</h1>
			<h2>Lectures</h2>
				<ul>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week05/exercises/loadStuff.html">LoadStuff</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week05/exercises/loadWaitStuff.html">loadWaitStuff</a></li>
				</ul>
				
			<h2>Examples</h2>
				<ul>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week05/exercises/file1.html">File1</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week05/exercises/file2.html">File2</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week05/exercises/frameContents.html">frameContents</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week05/css_test_done.html">CSS Test Done</a></li>
				</ul>
				
			<h2>Readings</h2>
				<ul>
					<li><a href="http://www.brainjar.com/css/positioning/default.asp">BrainJar: CSS Positioning Tutorial</a></li>
					<li><a href="http://www.webreference.com/html/tutorial18/index.html">WebReference: CSS Positioning Tutorial</a></li>
					<li><a href="http://alistapart.com/article/practicalcss">A List Apart: Practical CSS Layout Tips</a></li>
					<li><a href="http://www.ist.rit.edu/~jxs/classes/archive/2005_Fall/320/week_02/BasicCSS_00.mov">Prof Sonstein: General CSS review</a></li>
					<li><a href="http://www.w3schools.com/css/css_positioning.asp">W3Schools: CSS Positioning Properties Table</a></li>
				</ul>
		
	</div>
	<footer> Professor Sims </footer>
	</body>

</html>