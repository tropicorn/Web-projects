<!DOCTYPE html>    
<html lang="en">
	<head>
	
		<meta charset="utf-8" />
		<title>409 Group 4 Final</title>
		
	<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	
	</head> 

	<body> 

	<?php
			include("../mainNav.inc.html");
	?>

	<div class="banner">
	Banner here
	</div>
	
	<div id="sub"> 
	<h1> Submenu </h1>
	
	<?php
		include("../lecturesNav.inc.html");
	?>

	</div>
	
	<div id="content">
		
		<h1>Week 2</h1>
			<h2>Lectures</h2>
				<ul>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week02/infoArch.html">Info Arch</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week02/infoArchBasics.html">Info Arch Basics</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week02/organization.html">Organization</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week02/introCSS.html">Intro to CSS</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week02/basicCSS.html">basicCSS</a></li>
				</ul>
				
			<h2>Examples</h2>
				<ul>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week02/example_00.html">Example</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week02/example_01.html">Example1</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week02/example_02.html">Example2</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week02/example_03.html">Example3</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week02/unix1.html">Unix1</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week02/unix2.html">Unix2</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week02/unix3.html">Unix3</a></li>
				</ul>

			<h2>Readings</h2>
				<ul>
					<li><a href="http://www.webstyleguide.com/index.html?/sites/site_design.html">Yale Style Guide - Site Design</a></li>
					<li><a href="http://www.webmonkey.com/2010/02/information_architecture_tutorial/">Information Architecture Tutorial - Webmonkey</a></li>
					<li><a href="http://oreilly.com/catalog/navigation/chapter/ch05.html">Designing the User Experience - Jennifer Fleming</a></li>
					<li><a href="http://zing.ncsl.nist.gov/hfweb/proceedings/tiller-green/">Web Navigation - Tiller and Green</a></li>
					<li><a href="http://www.jjg.net/ia/visvocab/">A Visual Vocabulary - J.J.Garrett</a></li>
					<li><a href="http://www.nngroup.com/articles/eyetracking-study-of-web-readers/">Eye Tracking Study of Web Users - Jakob Nielsen</a></li>
				</ul>
				
			<h2>Online Webmaster Resources</h2>
				<ul>
					<li><a href="http://www.natural-innovations.com/wa/doc-charset.html">HTML Character Entities</a></li>
					<li><a href="http://www.ficml.org/jemimap/style/color/wheel.html">Color Wheel</a></li>
					<li><a href="http://www.w3.org/QA/Tips/">Quality Tips for Webmasters</a></li>
					<li><a href="http://chrispederick.com/work/web-developer/">Web Developer Extension Menubar</a></li>
					<li><a href="http://validator.w3.org/checklink">W3C Link-Checker</a></li>
					<li><a href="http://www.nngroup.com/articles/the-top-ten-web-design-mistakes-of-1999/">The Top Ten New Mistakes of Web Design</a></li>
				</ul>
		
	</div>
	<footer> Professor Sims </footer>

	</body>
	
</html>