<!DOCTYPE html>    
<html lang="en">
	<head>
	
		<meta charset="utf-8" />
		<title>409 Group 4 Final</title>
		
	<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	
	</head> 

	<body> 

	<?php
			include("../mainNav.inc.html");
	?>

	<div class="banner">
	Banner here
	</div>
	
	<div id="sub"> 
	<h1> Submenu </h1>
	
	<?php
		include("../lecturesNav.inc.html");
	?>

	</div>
	
	<div id="content">
		
		<h1>Week 1</h1>
			<h2>Lectures</h2>
				<ul>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week01/coursepage.html">Course</a></li>
					<li><a href="http://people.rit.edu/mab1311/409/final/groupFinal/lectures/week01/review.html">Review</a></li>
				</ul>

			<h2>Readings</h2>
				<ul>
					<li><a href="http://www.webstandards.org/">WebStandards.org</a></li>
					<li>Usability article: <a href="http://www.nngroup.com/articles/are-users-stupid/">Are Users Stupid?</a> by Jakob Nielsen</li>
					<li>Interaction Design article: <a href="http://www.nngroup.com/articles/progressive-disclosure/">Progressive Disclosure</a> by Jakob Nielsen</li>
				</ul>

	</div>
	<footer> Professor Sims </footer>
		
	</body>

</html>