<!DOCTYPE html>    
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<title>409 Group 4 Final</title>
	<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	
	</head> 

	<body> 

	<?php
			include("../mainNav.inc.html");
	?>

	<div class="banner">
	Banner here
	</div>
	
	<div id="sub"> 
	<h1> Submenu </h1>
	
	<?php
		include("../lecturesNav.inc.html");
	?>

	</div>
	
	<div id="content">
		
		<h1>Lectures</h1>
		
		<p>The lectures section allows you to follow along with the current lecture, understand the demos, and keep up with the readings. Each week has its own page with the entire week's content.</p>
		
	</div>
	<footer> Professor Sims </footer>

	</body>
	
</html>