<!DOCTYPE html>
<html>
	
	<head>
		
		<meta charset="utf-8" />
		<title>4002.409 Website Design and Implementation</title>
		
		<link rel="stylesheet" href="../styleFinal.css" type="text/css">

	</head>
	
	<body>
		
		<?php
			include("../mainNav.inc.html");
		?>

		<div class="banner">
		Banner here
		</div>
	
		<div id="sub"> 
		<h1> Submenu </h1>

		<?php
			include("../projectsNav.inc.html");
		?>

		</div>
	
	<div id="content">
		
		<h1>Individual Final</h1>
		
		<h2>Assignment</h2>
		
		<p>Using a few of the technologies we've covered in the second half of the course (javascript, dhtml, PHP, etc.), re-create and redesign your original individual midterm Web site. Demonstrate your increased skills in more than one area covered in the second half of the course (javascript, dhtml, PHP, etc.). You may need to expand the content of the Web site. Include as a part of your project a separate linked page documenting what you have done in each area. The idea is to demonstrate you have learned something in the second half of this term about how to build Web sites and pages. The resulting project should be quite a bit different from or very much refined from your individual midterm Web site.</p>
		
		<h2>Due Date</h2>
		
		<p>Due not later than 11:59 P.M. on Monday night of Final-Exam week (20 percent of final grade)</p>
		
	</div>
		<footer>Professor Sims</footer>
		
	</body>
	
</html>