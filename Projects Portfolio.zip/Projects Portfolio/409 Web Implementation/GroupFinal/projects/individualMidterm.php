<!DOCTYPE html>
<html>
	
	<head>
		
		<meta charset="utf-8" />
		<title>4002.409 Website Design and Implementation</title>
		
		<link rel="stylesheet" href="../styleFinal.css" type="text/css">

	</head>
	
	<body>
		
		<?php
			include("../mainNav.inc.html");
		?>

		<div class="banner">
		Banner here
		</div>
	
		<div id="sub"> 
		<h1> Submenu </h1>

		<?php
			include("../projectsNav.inc.html");
		?>

		</div>
	
	<div id="content">
		
		<h1>Individual Midterm</h1>
		
		<h2>Assignment</h2>
		
		<p>Create an introductory UNIX tutorial website. All materials for this individual site must be written by you in your own words. You may not use anything from anywhere else at all. All code, graphics, images, etc for this site must have been created by you. You may not use anything from anywhere else at all. In other words, this is a website that you make ... all by yourself. Did I remember to mention that you must make everything for this project?</p>
		
		<h2>Due Date</h2>
		
		<p>Due not later than 11:59 P.M. on Wednesday night of week 5 (20 percent of final grade)</p>
		
		<h2>Grading Rubric</h2>
		
		<p>The website should include at least 20 separate pages linked (that's 20 separate .html files, or the equivalent with permission of the instructor). You will be graded on your:</p>
		
		<ol>
			
			<li>Basic Design</li>
				<ul>
					
					<li>Layout on Multiple Browsers and Resolutions</li>
					<li>CRAP Principles</li>
					
				</ul>
			<li>Organization of Information</li>
				<ul>
					
					<li>Content Grouped Appropriatly</li>
					<li>Inter and Intra Information Links</li>
					
				</ul>
			<li>Content</li>
				<ul>
					
					<li>Appropriate Amount of Content</li>
					<li>All Content in Own Words</li>
					<li>Sources</li>
					
				</ul>
			<li>Navigation</li>
				<ul>
					
					<li>Page Indicators</li>
					<li>Global and Local Navigation</li>
					
				</ul>
			<li>HTML and CSS (Text and Positioning)</li>
				<ul>
					
					<li>Valid HTML</li>
					<li>Valid CSS</li>
					
				</ul>
			
		</ol>
		
		<p>Include as a part of your project a separate linked "About" Web page or set of pages documenting what you have done in each and every grading category above.</p>
		
	</div>
		<footer>Professor Sims</footer>
		
	</body>
	
</html>