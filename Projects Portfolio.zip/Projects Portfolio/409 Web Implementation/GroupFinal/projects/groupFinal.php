<!DOCTYPE html>
<html>
	
	<head>
		
		<meta charset="utf-8" />
		<title>4002.409 Website Design and Implementation</title>
		
		<link rel="stylesheet" href="../styleFinal.css" type="text/css">

	</head>
	
	<body>
		
		<?php
			include("../mainNav.inc.html");
		?>

		<div class="banner">
		Banner here
		</div>
	
		<div id="sub"> 
		<h1> Submenu </h1>

		<?php
			include("../projectsNav.inc.html");
		?>

		</div>
	
	<div id="content">

		<h1>Group Final</h1>
		
		<h2>Assignment</h2>
		
		<p>Implement the site design document which your group created for the Midterm Project.</p>
		
		<h2>Due Date</h2>
		
		<p>Due not later than the start of the scheduled Final Exam time posted by RIT (20 percent of final grade)</p>
		
	</div>
		<footer>Professor Sims</footer>
		
	</body>
	
</html>