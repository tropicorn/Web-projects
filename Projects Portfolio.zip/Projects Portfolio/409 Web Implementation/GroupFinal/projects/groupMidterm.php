<!DOCTYPE html>
<html>
	
	<head>
		
		<meta charset="utf-8" />
		<title>4002.409 Website Design and Implementation</title>
		
		<link rel="stylesheet" href="../styleFinal.css" type="text/css">

	</head>
	
	<body>
		
		<?php
			include("../mainNav.inc.html");
		?>

		<div class="banner">
		Banner here
		</div>
	
		<div id="sub"> 
		<h1> Submenu </h1>

		<?php
			include("../projectsNav.inc.html");
		?>

		</div>
	
	<div id="content">
		<h1>Group Midterm</h1>
		
		<h2>Assignment</h2>
		
		<p>The design of the Web "site" for this course has not been reworked for quite some time, and it could be much better. The task for your teams is to design (and then implement for the final group project) a new site for this course, and one which works equally well on everything from an Internet-connected "big screen" television down to handheld and mobile devices.</p>
		
		<h2>Details</h2>
		
		<h3>Design Document</h3>
		
		<p>The WebMonkey Information Architecture Tutorial should be used to provide the structure for your design document. The design document should be completely online and should not just say what you want to do. The design document should also clearly show why you have chosen whatever approach and content and etc which you choose to use.
		You may choose to use either XHTML 1.0 (Strict) or HTML5, and you may use CSS 2.1 or 3. In each case, you need to say why you chose one over the other to write your design document and why you chose one over the other for the final site design.</p>
		
		<h3>Site Design Document</h3>
		
		<p>Your group will create a Site Design Document with page mock-ups using the WebMonkey Information Architecture Tutorial format. Note that there are 5 lessons on the site, each one dealing with multiple sub-sections of the document. Your group needs to create a design document that explicitly deals with each and every WebMonkey lesson.
		Developing and presenting this sort of document is not a trivial task, and this sort of work makes a lot of consulting firms a lot of money. Web-aware companies know having a good design document will save them money and heartache in actually getting a website up and running smoothly, in keeping it running properly, and in changing it over time as their needs change.</p>
		
		<h3>WebMonkey Information Architecture Tutorial Link</h3>
		
		<a href="http://www.webmonkey.com/2010/02/information_architecture_tutorial/">WebMonkey Information Architecture Tutorial</a>
		
		<h2>Due Date</h2>
		
		<p>Due not later than 11:59 P.M. on Wednesday night of week 6 (20 percent of final grade)</p>
		
		<h2>Design Document Items</h2>
		
		<ol>
			
			<li>Goals</li>
			<li>User Experience</li>
				
				<ul>
					
					<li>Audience</li>
					<li>Scenarios</li>
					<li>Competative Analysis</li>
					
				</ul>
				
			<li>Content</li>
				
				<ul>
					
					<li>Content Grouping and Labeling</li>
					<li>Functional Requirements</li>
					<li>Content Inventory</li>
					
				</ul>
				
			<li>Site Structure</li>
				
				<ul>
					
					<li>Site Structure Listing (or Summary)</li>
					<li>Architectural Blueprints</li>
					<li>Global and Local Navigation Systems</li>
					
				</ul>
			
			<li>Visual Design</li>
				
				<ul>
					
					<li>Layout Grids</li>
					<li>Design Sketches</li>
					<li>Page Mock-Ups</li>
					<li>Web-Based Prototypes</li>
					
				</ul>
			
		</ol>
		
		<h2>Group Leaders</h2>
		
		<p>I will expect group leaders to create a group project Web page/site, and to post a series of progress notes to that page/site. Post at least one note per week. These notes should detail the progress of your group towards meeting the requirements of the project that week, and should reflect what each and every member of your group is going to accomplish in the following week.
		In other words, group leaders are expected to post on the group Web page/site each and every week at least one note about what concrete and measurable objectives:</p>
		
			<ol>
			
				<li>Your team as a whole has completed in the previous week and will complete by the time you post again the following week</li>
				<li>Each and every member of your team individually has completed in the previous week and will complete by the time you post again the following week</li>
			
			</ol>
		
	</div>
		<footer>Professor Sims</footer>
		
	</body>
	
</html>