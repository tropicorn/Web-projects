<!DOCTYPE html>
<html>
	
	<head>
		
		<meta charset="utf-8" />
		<title>4002.409 Website Design and Implementation</title>
		
		<link rel="stylesheet" href="../styleFinal.css" type="text/css">

	</head>
	
	<body>
		
		<?php
			include("../mainNav.inc.html");
		?>

		<div class="banner">
		Banner here
		</div>
	
		<div id="sub"> 
		<h1> Submenu </h1>

		<?php
			include("../projectsNav.inc.html");
		?>

		</div>
	
	<div id="content">
		
		<h1>Projects</h1>
		
		<p>This section gives the assignments and criteria for completing the four major projects in this course. The links to the left give more details about what each assignment is.</p>
		
	</div>
		<footer>Professor Sims</footer>
		
	</body>
	
</html>