<!DOCTYPE html>
<html>

	<head> 
	<meta charset="utf-8" />
	<title> Web Design & Implementation 409 - Information </title>

	<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	
	</head> 

	<body> 

	<?php
			include("../mainNav.inc.html");
	?>

	<div class="banner">
	Banner here
	</div>
	
	<div id="sub"> 
	<h1> Submenu </h1>
	
	<?php
		include("../courseOverviewNav.inc.html");
	?>

	</div>
	
	<div id="content">
	<h1>Course Information</h1>

	<p> Here is where you can find all the information related to this course - 409 Web Design & Implementation </p>
	<p> These links will take you to the introduction of the course, requirements, textbooks and accounts, grading on assignments and projects, and the roster of the classes currently being taught.</p>
	
	</div>
	<footer> Professor Sims </footer>


	</body>
</html>