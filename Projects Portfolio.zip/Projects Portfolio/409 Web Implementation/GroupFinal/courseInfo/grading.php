<!DOCTYPE html>
<html>

	<head> 

		<meta charset="utf-8" />
		<title> Web Design & Implementation 409 - Information </title>

		<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	</head> 

	<body>
		
		<?php
			include("../mainNav.inc.html");
		?>
		
		<div class="banner">
		Banner here
		</div>

		<div id="sub"> 
		<h1> Submenu </h1>

		<?php
			include("../courseOverviewNav.inc.html");

		?>

		</div>

		<div id="content">
		<h1> Grading </h1>
			<h2> Grading Components</h2>
				<h3>Projects (20% each)</h3>
				<ul>
					<li>Individual Midterm Web Project: Specifications
					<li>Group Midterm Site Design Document: Written Paper
					<li>Individual Final Web Project: More and Better
					<li>Group Final Web Project: Final Group Presentation
				</ul>
				
				<h3>Practical Exam (20%)</h3>
				<ul>
					<li>Timed, in-class practical exam
				</ul>
				
				<h3>Participation (up to 10%)</h3>
				<ul>
					<li>Attendance, class participation
				</ul>
				
				<h3>Total Possible: 110%</h3>
			
			<h2> Final Grades</h2>
				<p>A final letter grade will be assigned from points that you have accumulated (e.g. A = 90-100&#37;,
				B = 80-90&#37;, etc.). <strong>I do not grade on a curve</strong>, so if every student does "A"
				work, then every student gets an "A" (or a "D", as the case may be...).</p>
				<p>It is important to understand that if you complete all the requirements for an assignment, that
				is only sufficient for a grade of "C" (i.e. "satisfactory work"). To receive an "A" for an assignment,
				you must go beyond the basic requirements, and show creativity, initiative, and <em>excellence</em>.</p>
				<p>The grade of "A" is intended for work that is clearly superior, rather than average.</p>
				<p>If you wish to dispute your final course grade, you must do so before the end of the quarter following this one;
				after that, documentation of your work may be discarded.</p>
			
			<h2> Late Assignments</h2>
				<p>Assignments submitted after the due date/time, without prior approval from me, will lose 50&#37; for each day
				that they are late. If you know that a situation will prevent you from turning something in, contact me
				<i>in advance</i> of the deadline to make alternate arrangements.</p>
			
			<h2> The Practical</h2>
				<p>All the projects you do for this class are significant enough that they are completed outside of class time.
				Amongst other things, the practical examination at the end of the term is designed to show us that you
				personally can do minimally competent work in creating a page using HTML, CSS, &amp; JavaScript. By
				<em>&quot;minimally competent&quot;</em> I mean: (1) all the code is valid &amp; well-formed, (2) the
				CSS does what it is supposed to do to the browser display, and (3) the JavaScript adds the functionality
				it is supposed to add to the page. This is not a hard test, but you will &quot;fail&quot; the practical
				examination if any one of these three minimal expectations is completely missing or seriously flawed in
				execution.</p>
				
				<ul>
					<li>4002.409.04/4004.737.02 Final Exam - Monday, May 13<super>th</super> - 10:15AM-12:15PM - GOL (70)-2620</li>
					<li>4002.409.02 Final Exam - Friday, May 17<super>th</super> - 10:15AM-12:15PM - GOL (70)-2520</li>
				</ul>
			<h2> Dropping/Withdrawing From the Course</h2>
				<h3>Last day to drop</h3>
					<p>For this quarter, you can add/drop a class on or before <strong>Sunday, March 10<super>th</super>, 2013</strong>. After that date, 
					you must withdraw from the course, which will show on your transcript as a "W".</p>
				
				<h3>Last day to withdraw</h3>
					<p>The deadline for withdrawing from a course with a "W" grade is <strong>Friday, April 26<super>th</super>, 2013</strong>. Forms may 
					be obtained from the IT office, and must be signed by your instructor. Completed forms should be returned 
					to the IT office no later than <strong>Friday, April 26<super>th</super>, 2013</strong>. After that date, a grade will be assigned based 
					on the work that you have submitted.</p>
					
			<h2> Incomplete Grades</h2>
				<h3>Requesting</h3>
					<p>You may request an incomplete (a grade of "I") only in cases where exceptional conditions beyond your control, 
					such as accidents, severe illness, family problems, etc., have kept you from completing the course. <em>You 
					must alert us to these circumstances as soon as possible</em>. Telling your instructor in February that you 
					were sick in December is not acceptable.</p>
					
					<p><strong>Incomplete grades are not given to students who have simply fallen behind in their work</strong>.</p>
				<h3>Completing</h3>
					<p>If your request is granted, then you must complete the work for the course within the time limits set by the instructor. 
					<i>The maximum time to complete a grade of "I" is two (2) academic quarters. After that time, grades of "I" automatically 
					become grades of "F"</i>.</p>
					
			<h2> Coding Standards</h2>
				<p>Like any other IT course, 409 has simple coding standards. We practice using the <em>Model-View-Controller</em>
				paradigm here, so all HTML, CSS, and JavaScript must be maintained in seperate files, All pages must be
				constructed of <em>valid &amp; well-formed</em> (I will use the <a href="http://validator.w3.org/">W3C validation services</a> 
				to check) HTML5, CSS 3, and JavaScript.
				The HTML must just be HTML, no embedded or inline CSS or JavaScript or style attributes or such. The CSS
				must actually do what the assignment says it is supposed to do, and the JavaScript must actually add the
				functionality the assignment calls for. No matter how pretty your code, it must actually do what the
				assignment calls for. All resources must be maintained on RIT servers, unless you get prior permission
				from the instructor.</p>
					
				<p>The code required of you for this class is cross-platform &amp; cross-browser HTML5,
				CSS3, &amp; JavaScript. This is not a server-side class, although you will be exposed to PHP and
				other server-side technologies. Focus on writing cross-platform &amp; cross-browser HTML, CSS, &amp; JavaScript
				code.</p>
			
			<h2> Academic Honesty</h2>
				<p><strong>Each student must write their own code, or include clear attribution statements in the source
				file(s) and in writeup(s) if they use or modify code created by someone else. <i>Failure to give proper
				attribution will result in a grade of "F" on that assignment or possibly in the course, and may be treated
				as a case of academic dishonesty.</i></strong></p>
		</div>
		<footer> Professor Sims </footer>

	</body>
</html>