<!DOCTYPE html>
<html>

	<head> 

		<meta charset="utf-8" />
		<title> Web Design & Implementation 409 - Information </title>

		<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	</head> 

	<body> 
		
		<?php
			include("../mainNav.inc.html");
		?>
		
		<div class="banner">
		Banner here
		</div>

		<div id="sub"> 
		<h1> Submenu </h1>

		<?php
			include("../courseOverviewNav.inc.html");

		?>

		</div>

		<div id="content">
		<h1> Course Roster </h1>
			<li>
			<a href="http://people.rit.edu/smsshc/409/4002-409-04_4004-737-02.php"> Course Roster </a> 
			</li>
			
			<h3>4002.409.04</h3>
					
						<ol>
							<li>
								<a href="http://people.rit.edu/fxa5706/409/">Abolhassani, Fareed</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/kmb7571/409/">Barbauld, Kyle</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/jjb7226/409/">Bird, Jeffrey</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/msb5987/409/">Brady, Matthew</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/mab1311/409/">Butler, Michaela</a>
								
							</li>
							
							<li>
								<a href="http://people.rit.edu/dac1647/409/">Crocker, David</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/add5980/409/">Distasi, Andrew</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/yxe1545/409/">Elt, Yuri</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/kjh7831/409/">Ha, Kevin</a>
								
							</li>
							
							<li>
								<a href="http://people.rit.edu/mmh5626/409/">Hassan, Mohd</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/jxh3360/409/">Hong, Jisun</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/kmm9902/409/">Mc Gee, Kristine</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/cmm9745/409/">Menzel, Christopher</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/njm5586/409/">Miloscia, Nicholas</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/qxn8749/409/">Nguyen, Quang</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/cjs8972/409/">Stevens, Christopher</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/jmt4735/409/">Theismann, Jonathan</a>
								
							</li>
							
							<li>
								<a href="http://people.rit.edu/hxz2012/409/">Zendano, Henry</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/adz9160/409/">Zurkowski, Aleksey</a>
							</li>
						</ol>
						<h3>4004.737.02</h3>
			
						<ol>
							<li>
								<a href="http://people.rit.edu/nia9393/737/">Allheeib, Nasser</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/bpf4347/737/">Furton, Barret</a>	
							</li>
							
							<li>
								<a href="http://people.rit.edu/rxg3285/737/">Gadde, Raviteja</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/krh9506/737/">Hollenbeck, Katie</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/smn3711/737/">Nadal Carbuccia, Sandy</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/nxp8272/737/">Prasannakumar, Niveditha</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/abr4262/737/">Rondon Lopez, Abel</a>
							</li>
							
							<li>
								<a href="http://people.rit.edu/mxy3663/737/">Yabe, Mitsuyoshi</a>
							</li>
						</ol>

		</div>
		<footer> Professor Sims </footer>


	</body>
</html>