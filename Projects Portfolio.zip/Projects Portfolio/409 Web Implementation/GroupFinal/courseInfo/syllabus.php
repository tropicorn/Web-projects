<!DOCTYPE html>
<html>

	<head> 

		<meta charset="utf-8" />
		<title> Web Design & Implementation 409 - Information </title>

		<link rel="stylesheet" href="../styleFinal.css" type="text/css">
	</head> 

	<body>
		
		<?php
			include("../mainNav.inc.html");
		?>
		
		<div class="banner">
		Banner here
		</div>

		<div id="sub"> 
		<h1> Submenu </h1>

		<?php
			include("../courseOverviewNav.inc.html");

		?>

		</div>

		<div id="content">
			<h1> Syllabus </h1>
						
			<h2> Prerequisite Knowledge </h2>
			<p> <strong>Important note regarding prerequisite knowledge:</strong> I will expect that you have a solid base of prior knowledge about basic HTML and CSS 
			coding and the use of UNIX in a command-line environment. You should be familiar with coding using programmers' text editors, 
			use of graphics editors, and basic design principles for the Web, as well as UNIX commands for creating, deleting, renaming, 
			and changing permissions for files and directories. I recommend "The UNIX Programming Environment" as a good basic text and reference. 
			In addition, in this course I assume that you have basic programming skills � the particular language is not important, but an understanding 
			of programming concepts is important. </p>
			
			<h2> Coding Standards </h2>
			<p> Students are expected to already know how to produce valid and well-formed HTML 4.01(Strict) and CSS (Level 2.1). 
			In this course we will work with HTML5 APIs, tags, attributes, and ideas and with CSS3. 
			All coding must be done "by hand" within a text or programmer's editor. Do not use Dreamweaver� or other such drag-and-drop editors, 
			as they conceal too much of the code for our educational purposes. </p>
			
			<h2> Primary Topics </h2>
			<ul>
				<li>information design & architecture
				<li>layout, graphic design & web gestalt
				<li>XML-derived markup & the Document Object Model (DOM)
				<li>Cascading Style Sheets (CSS)
				<li> JavaScript
				<li> buttons, menus & other navigational control approaches
				<li> Web-based forms & validation
				<li>introduction to basic server-side technologies
			</ul>
		</div>
		
		<footer> Professor Sims </footer>

	</body>
</html>