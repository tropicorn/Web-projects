<!DOCTYPE html>
<html>

	<head> 

		<meta charset="utf-8" />
		<title> Web Design & Implementation 409 - Information </title>
		
		<link rel="stylesheet" href="../styleFinal.css" type="text/css">

	</head> 

	<body>
		
		<?php
			include("../mainNav.inc.html");
			
		?>

		<div class="banner">
		Banner here
		</div>
	
		
		<div id="sub"> 
		<h1> Submenu </h1>
		
		<?php
			include("../courseOverviewNav.inc.html");
		?>
		</div>

		<div id="content">
		<h1> Texts </h1>
			<h2> Books </h2>
			<p>There are no required texts for this course. There is an enormous amount of online material available for free, 
			and it is more current than any printed books. </p>
			
			<h2> Readings </h2>
			<p>Online readings will be assigned almost every week, and will be linked from this course Website. 
			Other reading assignments may be provided or assigned as appropriate. </p>
			
			<h2> Materials </h2>
			<p>You should purchase and use a USB "thumb drive" or other robust media to save your work. Save early and save often.</p>

		<br>

		<h1> Accounts </h1>
			<h2> DCE Account</h2>
			<p>Your DCE ID and password actually gives you access to multiple systems here at RIT. 
			In this class, you will need a DCE account in order to access <i> gibson.rit.edu</i>, the RIT UNIX system that will store your WWW pages. 
			You will also need it to access the RIT webmail service. You probably already have this account, but if you don't 
			(or if you have problems with it), bring your student ID to the <a href="http://www.rit.edu/its/help"> ITS Help Desk </a>to get your DCE account set up. </p>
		</div>
		
		<footer> Professor Sims </footer>

	</body>
</html>