<?php
	// Your PHP code goes here
	
	include('functions.php');
	
	// If the form is submitted, determine what the action was.
	// NOTE: $_POST[�action�] refers to the hidden field in our
	// form. We could have multiple forms and setup to handle
	// multiple actions based on the hidden field value all in one
	// block of code in one file.
	$action = isset($_POST['action']) ? $_POST['action'] : "";
	
	if ($action == 'Create') {
		// Process the submitted data
		$userID = $_POST['user'];
		$points = $_POST['points'];
		$passFail = $_POST['passFail'];
		$attendance = $_POST['attendance'];
		$server = $_POST['server'];
		$result = saveData($userID, $points, $passFail, $attendance, $server);
	}
	
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<title>Database-Enabled Form Example</title>
	</head>
	<body>
		<form name="example" action="" method="POST" enctype="multipart/form-data">
			<label>User: 
				<select name="user">
					<option value="">Please Select A User</option>
					<?php
						// Retrieve list of user's names from users table
						echo getUsersNamesAsOptions();
					?>
				</select>
			</label><br /><br />
			<label>Points: <input type="text" name="points" /></label><br /><br />
			Pass/Fail: <label><input type="radio" name="passFail" value="1" /> Pass</label> <label><input type="radio" name="passFail" value="0" /> Fail</label><br /><br />
			Attendance:<br />
			<label><input type="checkbox" name="attendance[]" value="1A" /> Week 1 Day 1</label> <label><input type="checkbox" name="attendance[]" value="1B" /> Week 1 Day 2</label><br />
			<label><input type="checkbox" name="attendance[]" value="2A" /> Week 2 Day 1</label> <label><input type="checkbox" name="attendance[]" value="2B" /> Week 2 Day 2</label><br />
			<label><input type="checkbox" name="attendance[]" value="3A" /> Week 3 Day 1</label> <label><input type="checkbox" name="attendance[]" value="3B" /> Week 3 Day 2</label><br />
			<label><input type="checkbox" name="attendance[]" value="4A" /> Week 4 Day 1</label> <label><input type="checkbox" name="attendance[]" value="4B" /> Week 4 Day 2</label><br />
			<label><input type="checkbox" name="attendance[]" value="5A" /> Week 5 Day 1</label> <label><input type="checkbox" name="attendance[]" value="5B" /> Week 5 Day 2</label><br />
			<br />
			<label>Server: <input type="text" name="server" list="serverList" /></label><br /><br />
			<input type="hidden" name="action" value="Create" />
			<input type="submit" name="submit" value="Save" />
			<datalist id="serverList">
				<option>Langley</option>
				<option>Lexington</option>
				<option>Saratoga</option>
				<option>Ranger</option>
				<option>Yorktown</option>
				<option>Enterprise</option>
				<option>Wasp</option>
				<option>Hornet</option>
				<option>Essex</option>
			</datalist>
		</form>
		<hr />
		<table border="1" cellpadding="3" cellspacing="0">
			<tr>
				<th>Record #</th>
				<th>User #</th>
				<th>Points</th>
				<th>Pass/Fail</th>
				<th>1A</th>
				<th>1B</th>
				<th>2A</th>
				<th>2B</th>
				<th>3A</th>
				<th>3B</th>
				<th>4A</th>
				<th>4B</th>
				<th>5A</th>
				<th>5B</th>
				<th>Server</th>
				<th>Created</th>
				<th>Updated</th>
			</tr>
			<?php
				// Retrieve list of records from the database
				echo getRecordsAsTableRow();
			?>
		</table>
	</body>
</html>