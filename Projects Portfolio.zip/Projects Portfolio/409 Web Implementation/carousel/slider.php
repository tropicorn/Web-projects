<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<title>409 Group 2 Final</title>
		<link rel="stylesheet" href="nivo-slider.css" type="text/css" media="screen" />
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
		<script src="jquery.nivo.slider.pack.js" type="text/javascript"></script>
	</head>
	<body>
		<div class="slider-wrapper">
			<div id="slider" class="nivoSlider">
				<img src="andy.png" alt="Andy DiStasi's Web Page" />
				<img src="michaela.png" alt="Michaela Butler's Web Page" />
				<img src="quang.png" alt="Quang Nguyen's Web Page" />
				<img src="sandy.png" alt="Sandy Nadal's Web Page" />
				<img src="nasser.png" alt="Nasser Allheeib's Web Page" />
			</div>
		</div>
		<script type="text/javascript">
			$(window).load(function() {
				$('#slider').nivoSlider();
			});
		</script>
	</body>
</html>