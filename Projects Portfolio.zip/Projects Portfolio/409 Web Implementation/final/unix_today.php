<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "today";
			$current_id = ' id="current"';
			include("menu.php");
		?>
	
		<h3> Unix Today </h3>

		<div id="content"> 
		
			<p>Since the invention started in 1960s, Unix is still undergoing a revolution to be implemented on today's computers and Android iOS.
			<p>The UNIX trademark is a separate entity from the actual Unix code stream itself, thus anyone can work with Unix to come up with 
			different implementations.
			 
			<p> Mac OS (Apple), iOS, and Linux are some of the well-known distributions of UNIX-based Operating System.
			Many servers are also written in Unix OS, due to its well-built security features.

			<p>Today, Unix OS's are split into different branches that have developed over time by commercial vendors 
			and non-profit organizations. 
			<p>The general file structure and security features of different implementations still resemble the original UNIX distribution. Several commands that weren't 
			in the original Unix also appear in different 
			distributions, and the filesystem underwent a lot of changes. 
			<p>However, the general file structure of most UNIX distributions resembles the originally developed version's structure.
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>