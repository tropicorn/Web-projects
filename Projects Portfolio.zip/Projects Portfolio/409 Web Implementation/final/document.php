<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "tutor";
			$current_id = ' id="current"';
			include("menu.php");
		?>
		
		<h3 id="text"> Documentation </h3>

		<div id="content"> 
		
			<p> Unix is the first OS to have its documentation available through the system as a user's guide.
				The documentation lists all of the usage of each command and display it on the shell.

			<p>On the command line, simply type:

			<p><b>man commandname </b>

			<p>If the entry has more lines than can fit on the screen, it displays one screen, then prints a prompt on the bottom line and waits. 
				Depends onthe system, the prompt will look like these:

			<p><b>more (x%)</b>
			<p><b>stdin </b>

			<p>Press SPACE bar to see another screen, or type <b>q</b> to quit. 
		<form>
		<input type="button" value="Back" onClick="history.go(-1);return true;">
		</form>

		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>


