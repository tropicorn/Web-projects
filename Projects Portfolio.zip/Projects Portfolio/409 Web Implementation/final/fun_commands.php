<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "tutor";
			$current_id = ' id="current"';
			include("menu.php");
		?>
		
		<h3> Fun commands to use </h3>

		<div id="content"> 
			<table border="1px"> 
				<tr>
				<td><b>who</b></td>
				<td>Lists who is currently logged on your machine</td>
				</tr>
				
				<tr>
				<td><b>finger</b></td>
				<td>Lists who is on computers in the same lab</td>
				</tr>
				
				<tr>
				<td><b>ytalk <user@place></b></td>
				<td>Talk online with a user on an email host</td>
				</tr>
				
				<tr>
				<td><b>history</b></td>
				<td>Lists commands done recently</td>
				</tr>
				
				<tr>
				<td><b>fortune</b></td>
				<td>Print random funny message</td>
				</tr>
				
				<tr>
				<td><b>date</b></td>
				<td>Print out current date</td>
				</tr>
				
				<tr>
				<td><b>cal<mo> <yr></b></td>
				<td>Print calendar in month specified followed by year</td>
				</tr>
				
				<tr>
				<td><b>xeyes</b></td>
				<td>Keep track of cursor </td>
				</tr>
				
				<tr>
				<td><b>mpage -8 file1 | lpr </b></td>
				<td>Print 8 pages on a single sheet and send to printer (the font will be small!) </td>
				</tr>
				
				<tr>
				<td><b>whoami</b></td>
				<td>returns your username. You may need to find out who it is that forgot to log out. </td>
				</tr>
				
				<tr>
				<td><b>webster word</b></td>
				<td>looks up a word in an electronic version of Webster's dictionary and returns the definition</td>
				</tr>

			</table>
		<br>
		<form>
		<input type="button" value="Back" onClick="history.go(-1);return true;">
		</form>

		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	</div>
	
	</body>

</html>




