<!DOCTYPE html>
<html lang="en-US">
	<head>
	<title> menu </title>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

	<script type="text/javascript">
		$(document).ready(function() {
		
			$('#menu li').hover(function() {
				$(this).find("ul").first().show();
				$(this).addClass("subItem");
			}, function() {	
				$(this).find("ul").first().hide();
				$(this).removeClass("subItem");
			});
			
			$("a[href='#']").click(function(){
				alert("Please select a topic to learn in this section!");
			});
			
		
		});
		
	</script>
	
	<style type="text/css">
	
		
		.subItem{
		background-color:#4f5964;
		}
		
	
	</style>
			
	</head>
	<body>
		<nav id="menu">
			<ul>
				<li <?php if ($selected == "home") print $current_id;?>><a href="index.php">Home</a></li>
				<li <?php if ($selected == "intro") print $current_id;?>> <a href="#">Unix Introduction</a>
				
					<ul>
						<li><a href="whatis_unix.php">What is Unix? </a></li>
						<li><a href="history.php">History of Unix </a></li>
						<li><a href="advantages.php">Advantages </a></li>
						<li><a href="disadvantages.php">Disadvantages </a></li>
						<li><a href="unix_info.php">Information Table</a></li>
					</ul>
				
				</li>
			
				<li <?php if ($selected == "tutor") print $current_id; ?>><a href="#">Unix Tutorial</a>
					<ul>
						<li><a href="unix_commands.php">Unix commands </a> </li>
						<li><a href="copy_paste.php">Copy and paste in Unix </a></li>
						<li><a href="#">Advanced commands  &nbsp > </a>
							<ul>
								<li><a href="head_adv.php">Head and tail</a></li>
								<li><a href="pipes.php">Pipelines</a></li>
								<li><a href="print_unix.php">Print</a></li>
							</ul>
						</li>
						
						<li><a href="components.php">Unix Components</a>
						<li><a href="permissions.php">Set permissions</a>
						<li><a href="wildcard.php">Unix wildcards</a>
						
					</ul>
				</li>
				<li <?php if ($selected == "linux") print $current_id; ?>><a href="#">Unix vs Linux</a>
					<ul>
						<li><a href="unix_linux.php">Differences</a></li>
						<li><a href="unix_OS.php">Unix OS</a></li>
						<li><a href="linux_OS.php">Linux OS</a></li>
					</ul>
					</li>
				<li <?php if ($selected == "today") print $current_id; ?>><a href="unix_today.php">Unix Today</a></li>
				<li <?php if ($selected == "about") print $current_id; ?>><a href="about.php">About</a></li>
			</ul>
		
		</nav>
		
		
	</body>
	
</html>