<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			include("menu.php");
		?>
	
		<h3> Process controls</h3>

		<div id="content"> 
		
			<p><b>command1& </b> &nbsp execute command1 in background
			<p><b>ps -ef</b> 	 &nbspprint expanded list of all processes
			<p><b>control-c</b> 	 &nbsp interrupt current process
			<p><b>control-z</b> 	 &nbsp suspend current process
			<p><b>jobs</b>  &nbsp	display background and suspended processes
			<p><b>kill 1</b>  &nbsp	remove process #1
			<p><b>top </b>  &nbsp	display the current, most computer-intensive commands
			<p><b>osview </b>  &nbsp	display the operating system statitistics
		
		<form>
		<input type="button" value="Back" onClick="history.go(-1);return true;">
		</form>

		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>




