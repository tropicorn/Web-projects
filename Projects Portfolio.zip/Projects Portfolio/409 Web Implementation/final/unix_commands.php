<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">
	
	</head>

	<body>
		
	<div id="container">
		<?php 
			$selected = "tutor";
			$current_id = ' id="current"';
			include("menu.php");
		?>
		
		<h3 id="text"> Basic UNIX Commands </h3>
		
		
		<div id="content"> 
		
			<table border="1" align="center">
				<tr>
				<td><b>Command</b></td>
				<td><b>Description</b></td>
				</tr>
				
				<tr>
				<td><b> ls</b> </td>
				<td> List files in current directory</td>
				</tr>
				
				<tr>
				<td><b> cd</b> </td>
				<td> Change directory </td>
				</tr>
				
				<tr>
				<td><b> mkdir</b> </td>
				<td> Make a new directory</td>
				</tr>
				
				<tr>
				<td><b> rm</b> </td>
				<td> Remove directory</td>
				</tr>
			</table>
		<p> <b>Examples:</b>
		<p><b>ls ~ </b>
		<p>shows all files in your home directory.

		<p><b>ls ~/prog</b>
		<p>shows all files in the sub-directory 'prog' in your home directory.

		<p><b>cd Desktop</b>
		<p>changes your working directory to be on the desktop. 
		
	
		<h3> More Unix commands:</h3>
		<div>
			
			<select onchange="window.location=this.value;">
			<optgroup>
			<ol>	
			<option selected="selected" disabled="disabled"> Select from dropdown list</option>
			<option value="access.php"> Accessing Unix </option>
			<option value="document.php"> Documentation </option>
					
			</optgroup>
			
			<optgroup label="File Manipulation">

					<option value="move_copy.php"> Moving and Copying file</option>
					<option value="show_files.php"> Show file </option>
					<option value="compress.php"> Compress a file</option>
						
			</optgroup>			

			<optgroup label="Miscellaneous">
									
					<option value="process_controls.php"> Process controls</option>
					<option value="fun_commands.php">Fun Unix commands!</option>
				</ol>
			</optgroup>
			</select>	
			
			
		</div>
		
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
	</div>
	
		
	</body>
</html>