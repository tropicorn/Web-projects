<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "tutor";
			$current_id = ' id="current"';
			include("menu.php");
		?>
	
		<h3 id="text"> head and tail </h3>

		<div id="content"> 
		
			<p><b>head</b>

			<p>The head command shows the first few lines of a file. By default, head shows only ten lines, 
			but the user can customize the number with -n option.
			
			<p><b>tail</b>

			<p>The tail command is opposite to head, it displays the last ten lines of the file. 
			Only works with a single file argument. <b>tail</b> also has other options to get the last x bytes or blocks, or to display lines in reverse 
			line order.

		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>


