<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "tutor";
			$current_id = ' id="current"';
			include("menu.php");
		?>
		
		<h3> Printing </h3>

		<div id="content"> 
		

			<p>The printing commands will print to the default printer nearest to the computer the user is logged into. 

			<p>After the user issued a print command, the print job is put into a queue and printed when all the print jobs 
			in the spool are done printing. 


			<p><b>To see the queued print jobs on all the printers</b> to which you can print, type:

			<p><i>% lpq</i>
			
			<p><b>To see the queued print jobs </b>on the specific printer, type:

			<p><i>% lpq -Pprinter-name</i>
			
			<p><b>To print a text file</b> to the <b>default</b> printer, type:

			<p><i>% enscript -2rG text-file.txt</i>
			
			<p><b>To print a text file to the specific printer, type:</b>

			<p><i>% enscript -2rG -Pprinter-name text-file.txt</i>
</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>

