<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "tutor";
			$current_id = ' id="current"';
			include("menu.php");
		?>

		<h3> Pipelines </h3>

		<div id="content"> 
			  <p> <b>Pipe symbol | </b>
				  <p>-send the output of one process into another process/program. If there are a lot of files in the current 
			   directory, try "ls -l | more", which makes "ls -l" send all of it"s output to "more" which then displays 
			   it one screen at a time. It can accept input from a program by putting it at the beginning before a filename
			   
				  <p><b>> filename </b>
					  <p>Redirect output print to a file. This will send the output of a command to the specified file. 
					  <p>For example, "ls -l > names.txt" will put the names and permissions of all 
					the files in the local directory into a file named "names.txt". 
		
				  <p><b> < filename </b>
					<p>Redirect input from a file. This will take everything in the file and send it 
					to a process that it came from the standard input ( keyboard ).  

				  <p><b>& </b>
				  <p>	Make a process run in the background automatically. The process must not 
					need input from the keyboard or output to the screen. 
					  <p>If the process is "cat file1 file2 > file3" and the file1 and file2 are too large to write to file 3. 
					To make it run in the background to continue to work while it is running, use the <b>& </b> at the end: "cat file1 file2 > file3 &". 

			
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>

