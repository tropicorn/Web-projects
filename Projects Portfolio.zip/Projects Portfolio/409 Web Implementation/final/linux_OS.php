<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "linux";
			$current_id = ' id="current"';
			include("menu.php");
		?>
	
		<h3> Linux Operating Systems </h3>

		<div id="content"> 
				<p><b>Distribution (Operating System) compatible with Linux:</b>

				<p>A few popular names:
					<ul>
						<li>Redhat Enterprise Linux</li>
						<li>Fedora Linux</li>
						<li>Debian Linux</li>
						<li>Suse Enterprise Linux</li>
						<li>Ubuntu Linux</li>
					</ul>
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>

