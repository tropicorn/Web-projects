<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "tutor";
			$current_id = ' id="current"';
			include("menu.php");
		?>
	
		<h3 id="text"> File compression </h3>

		<div id="content"> 
		

			<p><b>gzip filename </b>- compresses files with ending .gz to original name, to take up much less space. Usually 
			text files compress to about half the original size 
	
			<p><b>gunzip filename </b>- uncompresses files compressed by gzip.
			<p><b>gzcat filename </b>-lets you look at a gzipped file without actually
			unzip it. 
			<p><b>gzcat filename | lpr </b>- to print the zipped file directly and unzip in the process
		
		<form>
		<input type="button" value="Back" onClick="history.go(-1);return true;">
		</form>

		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>

