<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "intro";
			$current_id = ' id="current"';
			include("menu.php");
		?>
	
		<h3> Disadvantages </h3>

		<div id="content"> 
			<ul>
				<li>The command line shell interface is user hostile - designed for the programmer, not the casual user.
			<p>	
				<li>Commands have uncommon names and give little response to tell the user what they are doing. 
			<p>
				<li>Use of special keyboard characters as typos can have unexpected results.
			<p>	
				<li>Richness of over 400 standard utilities often confuses new users. Use of a documentation is recommended.
			</ul>
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>


