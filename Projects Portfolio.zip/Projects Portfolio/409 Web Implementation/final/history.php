<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">
	
	
	
	
	</head>

	<body>
		
	<div id="container">
		<?php 
			$selected = "intro";
			$current_id = ' id="current"';
			include("menu.php");
		?>
	
		<h3> Unix History </h3>

		<div id="content"> 
		
			<table align="center">

				<tr>
				<td><b>1969</b></td>
				<td>Unix was invented in 1969 at Bell Labs and what was to become Unix today.</td>
				</tr>
				

				<tr>
				<td><b> 1971</b> </td>
				<td> First Edition - used for simple text processing</td>
				</tr>
				

				<tr>
				<td><b> 1989</b> </td>
				<td> AT&T licensed Unix III, available to universities and commercial firms </td>
				</tr>
				
				<tr>
				<td><b> 1990</b> </td>
				<td> Open Software Foundation releases OSF/1, standard Unix based on BSD</td>
				</tr>
				
				<tr>
				<td><b> 2000</b> </td>
				<td> SCO sold its Unix business to Caldera Systems, which later changed to The SCO Group.</td>
				</tr>
				
				<tr>
				<td><b> 2007</b> </td>
				<td> Apple Mac OS X launches its Unix version</td>
				</tr>
			</table>
			
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
	</div>
	
		
	</body>
</html>
