<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "intro";
			$current_id = ' id="current"';
			include("menu.php");
		?>

		<h3 id="text"> Summary </h3>

		<div id="content"> 
		
			<table> 

				<tr>
				<td><b> Developers</b> </td>
				<td> Ken Thompson, Dennis Ritchie, Brian Kernighan, and Joe Ossanna at Bell Labs</td>
				</tr>
				
				<tr>
				<td><b> Programmed in</b> </td>
				<td> C and Assembly language</td>
				</tr>
				
				<tr>
				<td><b> OS family</b> </td>
				<td> Unix</td>
				</tr>
				
				<tr>
				<td><b> Working state</b> </td>
				<td> Current</td>
				</tr>
				
				<tr>
				<td><b> Source model</b> </td>
				<td> some Unix projects are open source</td>
				</tr>
				
				<tr>
				<td><b> Initial release	</b> </td>
				<td> April 20, 1969</td>
				</tr>
				
				<tr>
				<td><b> Available language(s)	</b> </td>
				<td> English</td>
				</tr>
				
				
				<tr>
				<td><b> Default user interface	</b> </td>
				<td> Command-line interface & Graphical (X Window System)</td>
				</tr>
				
				<tr>
				<td><b> Official website </b> </td>
				<td> <a href="http://unix.org"> http://unix.org</a></td>
				</tr>
				

			</table>
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>

