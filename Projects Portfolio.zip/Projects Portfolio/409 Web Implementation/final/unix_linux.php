<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "linux";
			$current_id = ' id="current"';
			include("menu.php");
		?>
		
		<h3> What is Linux? </h3>

		<div id="content"> 
		
			<p><b>Linux Is Just a Kernel</b>

			<p> To have a complete Linux program, one must obtain other components elsewhere.
			Most Unix operating systems are considered as a complete operating system 
			as everything come from a single source or vendor.

			<p>Most UNIX operating systems come with programs such as editor, compilers etc. 

			 
			<p> Developed by Linus Torvalds and later amended by a number of developers throughout the world. 
			 Linux is also a free multitasking and multiuser operating system. 
			 From the outset, Linux was placed under General Public License (GPL). The system can be distributed, used and expanded free of charge. 
			<p> In this way, developers have access to all the source codes, thus being able to integrate new functions or to find 
			 and eliminate programming bugs quickly. Thereby drivers for new adapters (SCSI controller, graphics cards, etc.) 
			 can be integrated very rapidly.

			<p><b>Is Linux Unix?</b>

			<p>An operating system is not yet allowed to be called a Unix until it passes the Open Group's certification tests,
			 and supports a set of necessary API (programming protocols). Nobody has yet sponsored the operating system by paying for the tests, 
			 so in the practical sense, it is Unix, but in the legal sense, it is not. 
			<p>Only a few of commercial operating systems have passed the Open Group tests.
			 
			 
			<p><b>User-Friendly</b>

			<p>Linux is considered as most user friendly Unix-like operating system. It is easy to install sound cards, flash players, 
			and other desktop peripherals. Apple OS is the most popular UNIX operating system for desktop usage as of today.

			<p>Linux also has more choices of software and drivers then most versions of Unix. 
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>


