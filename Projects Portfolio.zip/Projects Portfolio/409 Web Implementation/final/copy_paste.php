<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "tutor";
			$current_id = ' id="current"';
			include("menu.php");
		?>
	
		<h3> Unix Copy and Paste </h3>

		<div id="content"> 

				<p><b>To copy: </b>

				<p>hold down the middle mouse button and select desired text. 

				<p><b>To paste:</b>

				<p>click the middle mouse button where you want the copied text in the command line.
				 
				<p><b>Note:</b> 

				<p>Extreme large blocks of text being copied with the mouse may lose some data.
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>

