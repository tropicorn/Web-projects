<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "tutor";
			$current_id = ' id="current"';
			include("menu.php");
		?>
		
		
		<h3> Wildcards </h3>

		<div id="content"> 
		
			

				<p>A wildcard is a special character that can represent another set of characters if the user is unsure of that character.
				<p>The command line will automatically fill in the missing statement based on the wildcard used.

				<p><b>?</b> - any single character except a leading dot

				<p><b>*</b> - zero or more characters except a leading dot

				<p><b>[ ]</b> - set of characters

				<p><b>Example:</b>

				<p><b>ls abc*</b> - will fill in a character at the end that matches a file that begins with abc
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>


