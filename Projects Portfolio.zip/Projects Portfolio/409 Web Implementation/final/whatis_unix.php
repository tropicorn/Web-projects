<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

	<script type="text/javascript">
		$(document).ready(function() {
			$('#container').hover(function(){
					$("#content li").fadeIn('slow');

				},function(){
					$("#content li").fadeOut('slow');
				});
		});
		
	</script>
	
	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "intro";
			$current_id = ' id="current"';
			include("menu.php");
		?>
		
		<h3> What is Unix? </h3>

		<div id="content"> 
		
			<p>Unix is a multitasking, multi-user virtual computer operating system originally developed in 
			the 1960's by a group of AT&T employees at Bell Labs. 
		
			<p> Unix is used by the computer operating system: memory, processor, disks.
			Unix then directs those components to talk to peripherals like 
			<ul> <li> Keyboards 
				<li>Monitors 
				<li>Printers 
				<li>Disk Drives 
				<li>Programs
			</ul>
			

			<p>It is still used in many desktops, laptops, servers, and mobile devices today. Many Unix versions are not free to use, except for SUN-Solaris,
			which is free. Any low cost computer can run Unix. It is popular in use based on its simple enough design with a lot of
			 security features, and the fairly conventional language to translate across different machines. 
			 

			<p>Unix is different from other operating systems is that it is Multi-User - more than one person can use the computer at the same time.
			Each user can also run more than one program at the same time on one computer.
				
				
			<p>Most users are limited to 5-10 Megabytes of disk storage space.

			<p>Unix does not refer to a single operating system but is composed of several 
			implementations from different companies referred to as Unix flavors.

			<p>The most popular "flavors" of UNIX are Sun Solaris, GNU/Linux, and MacOS X.
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>

