<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			include("menu.php");
		?>
		
		<h3> Show files </h3>

		<div id="content"> 
		
			<p><b>pwd</b>

			<p>Tells the name of current working directory

			<p>Other options to ls provide different types of information.
			 
			<p><b>-a</b> &nbsp This will show files that begin with a dot character. 
			<p>This also gives information about the directory file itself (.) and its parent directory (..).
			 
			<p><b>-R</b> &nbsp This option first lists the files in the specified directory; 
			then if any of those files are themselves sub-directories, it lists their contents. This one can generate a lot of content output, use it with care.
			 
			<p><b>-F</b>  &nbsp This option is to give a quick indication of what kinds of files you have, 
			without making a long listing with the -l option. It does this by putting a / character after the name of 
			any file that is a sub-directory, and a wildcard * character after the name of any file that is executable. 
		
		<form>
		<input type="button" value="Back" onClick="history.go(-1);return true;">
		</form>

		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>




