<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">
	
	
	
	
	</head>

	<body>
		
	<div id="container">
		<?php 
			$selected = "tutor";
			$current_id = ' id="current"';
			include("menu.php");
		?>
		
		
		<h3> Permissions </h3>

		<div id="content"> 
		
			
			<p>Check ownership and permission settings on files and directories with the command ls -l

			<p>There are 3 groups of users: owner, group that the owner is in, and others. There are also 3 possible permissions: read, write, and execute.

			<p>To change permissions of a file, type:

			<p><b>chmod xxx file</b>

			<p>where each x represents a number from 1 to 7. The higher the number, the greater the permission that person is allowed to have

			<p>You can also use rwx format:

			<p><b>chmod -rwx rwx rwx file</b>

			<p>This command will set permissions for file so that the owner, group, and others can read, write, and execute the file. 


			<p><h3>Some examples:</h3>

			<p><i>chmod 600 filename</i>
			<p>	for text files that you want no one else to read or write. 
				
			<p><i>chmod 644 filename</i>
			<p>	for text files that others can read, but not write. 
				
			<p><i>chmod 755 filename</i>
			<p>	executable programs that others can execute, but not write. 
				
			
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
	</div>
	
		
	</body>
</html>


