<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "linux";
			$current_id = ' id="current"';
			include("menu.php");
		?>
		
		<h3> Unix Operating Systems </h3>

		<div id="content"> 
				<p><b>Operating Systems compatible with Unix:</b>

				<p>A few popular names:
					<ul>

						<li>HP-UX</li>
						<li>IBM AIX</li>
						<li>Sun Solairs</li>
						<li>Mac OS X</li>
						<li>IRIX</li>
												
					</ul>
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>

