<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "tutor";
			$current_id = ' id="current"';
			include("menu.php");
		?>
	
		<h3> Unix Components </h3>

		<div id="content"> 
		
			<p><b>Kernel</b>
			<p>The kernel is the memory of the system that controls computer resources and allow applications to communicate with the OS.
			
			<p><b>Shell</b>
			<p>The shell interacts with the user and the kernel. This runs what basically is known as "Command Line Interface". It translates 
			and executes commands from the user's inputs in the command line.
			
			<p><b>Applications</b>
			<p>The applications run on top of the shell that create functionality to the shell. Example is a GUI or a media player.
			
			<p><b>Command Line</b>

			<p>The command line (CLI) is the interaction between the user and the computer hardware components. 
			the CLI is the traditional method of input and output for UNIX users. 
			<p>All of the Unix commands are able to execute from the command line. 
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>





   