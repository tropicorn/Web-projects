<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">
	
	
	
	
	</head>

	<body>
		
	<div id="container">
		<?php 
			include("menu.php");
		?>
	
		<h3> Copy and move files </h3>

		<div id="content"> 
		
			
			<p><b>- To copy files, type:</b>

			<p><i>cp file1 file2</i>

			<p>*If file 2 already exists, it will be overwritten automatically.

			<p><b>To copy into a different directory, type:</b>

			<p><i>cp file1 directory</i>

			<p>Multiple files can be copied into any directory where you have permissions to write to.

			<p><i>cp file1 file2 file3 fileN directory</i>

			<p><b>- To move files </b>uses the same command as renaming files. The syntax is also similar with cp -

			<p><i>mv file1 directory/fileFoo</i>

		<form>
		<input type="button" value="Back" onClick="history.go(-1);return true;">
		</form>
			
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
	</div>
	
		
	</body>
</html>


