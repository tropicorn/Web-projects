<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

		<script type="text/javascript">
    	$(document).ready(function(){
        $("#mainMenu li a").click(function(){
		$("#mainMenu li").addClass("active");
		}), function() {
		$(this).parent().removeClass("active");
		});
		
   	 });
    </script>

	<script type="text/javascript">
		$(document).ready(function() {
			$('#content').hover(function(){
					$("p").fadeIn('slow');

				},function(){
					$("p").fadeOut('slow');
				});
		}); 
		
	</script>
	
	
	</head>

	<body>
		
<div id="container">
		<?php 
			$selected = "home";
			$current_id = ' id="current"';
			include("menu.php");

		?>
		
		
		<h3 id="text"> Welcome! </h3>

		<div id="content"> 

		<h3> Hello, today is <?php echo date('l, F jS, Y'); ?> </h3>
			
			This is a tutorial website introducing new users to UNIX.

			Here you will find information regarding every aspects UNIX as well as some background
			information about it. To get started, <u>click</u> on the menu items above.
		<p> Enjoy your stay!
			
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
	</div>
	
		
	</body>
</html>