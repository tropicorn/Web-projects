<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "intro";
			$current_id = ' id="current"';
			include("menu.php");
		?>
	
		<h3> Advantages </h3>

		<div id="content"> 
		
		<ul>
			<li><p><b>Multitasking</b></li> - Multiple users can run multiple programs each at the same time 
			without interfering with each other or crashing the system.
			
			<li><p><b>Efficient virtual memory </b></li>- many programs can run with little amount of physical memory.
			
			<li><p><b>Access controls and security </b></li>- users must be authenticated by an account and password to 
			use the system at all. Files are specific to a particular account. The owner can decide if others can 
			read or write access to his files.
			
			<li><p>A set of small commands that do specific tasks well </li>- <b>not cluttered</b> with a lot
			of special options.
		   
			<li><p> Ability to string commands together in unlimited ways to do more tasks on a single command line.</li>
		   
			<li><p><b>A unified file system</b></li> - Everything is a file: data, programs, and all physical devices. 
		   Entire file system appears as a single large directory tree, regardless of how many different 
		   system disks are included.
		   
			<li><p><b>RAM Memory </b> </li>- If a program crashes, it does not shut 
			down the entire PC, only affects the part of memory the 
			program was using before it crashed. 
		  
		   <p>A lean kernel that does the basics for you but doesn't get in the way when you try to do the unusual.
		   
		   <p>Available on most types of machine - a very portable operating system.
		   Optimized to do program development
		   
			<p>Users can also remote access to their computer using a Unix supported program
		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>




