<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">

	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "about";
			$current_id = ' id="current"';
			include("menu.php");
		?>
	
		<h3> About the site </h3>

		<div id="content"> 
		
			<p><h3>Basic Design</h3>
			<p>The website layout was designed based on the CRAP principles. Navigation in every page remains the same as the main page. 
			The color schemes are pretty basic, yet functional to the viewers. The viewers won't have a headache to navigate the site due to brighter
			colors.

			<p><h3>Organization of Information</h3>

			<p>The layout keeps all the content as centered as possible to focus the user's attention. The menu has brighter colors to pop out to viewers.
			All the subsequent menus use darker color scheme to enhance the item being targeted.

			<p>First I tried to fit all of the command pages on a single menu, but it was simply too big to navigate through. Therefore, I attempted to break down
			all the links and group them in a separate page called "Command", so the user can just click on the links if they wish to see the commands.
			
			<p><h3>Content</h3>

			<p>Some of the content for tutorial were revised from memory. Additional research was needed to gather information about other pages, such as
			History and Linux pages. 
			The structure of the content has been paraphased suitable to my needs.

			<p>No pictures were made possible without getting them from an outside source somewhere, as time was a constraint for me on making images from scratch.

			<p><h3>Navigation</h3>

			<p>The menu was drop-down effect in order to encompass sub-information under important information. There are 6 main menu items, and the 
			subsequent menu items are hidden until the user hover to make things appear neat and confined. 
			Instead of having a cluster of tutorial links, I referred to my information architecture model and created a menu link for 
			every category.

			<p><h3>Use of HTML and CSS</h3>
	
			<p>HTML5 is used across all pages. I chose the drop-down menu as my navigation and styled it using the CSS selectors.
			Every page uses the same CSS script to keep the theme and design synched with the CRAP design principles. This is also to reduce 
			the pageload amount of CSS on every page and to minimize confusions. CSS is also further used to create the site's color scheme using HEX color codes
			
			<p><h3>Use of PHP and Javascript</h3>
			
			<p> I chose PHP to create my navigation menu bar because it is simpler to link one PHP page that contains all
			the navigation links back in other pages. This however, required that I have to convert all of the existing HTML pages to
			.php. PHP allows me to spend less time working on the assignment and when the grader views it, it is less cluttered.
			<p>I also used jQuery to assimilate the CSS functions to drop down sub menu items when hovered. This is accomplished by setting the
			visibility of the submenus to 'hidden' before any hovering occurs. Also, this can alert the user if the page doesn't lead to anywhere.
			
			<p> Overall, the content of the site is pretty much the same/mostly similar to the content from the midterm project.
			
</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
		
	</div>
	
	</body>

</html>


