$(document).ready(function(){
	// global variables
	var form = $("#customForm");
	var name = $("#name");
	var nameInfo = $("#nameInfo");
	var email = $("#email");
	var emailInfo = $("#emailInfo");
	var password = $("#password");
	var passwordInfo = $("#passwordInfo");
	var confirm = $("#confirm");
	var confirmInfo = $("#confirmInfo");
	var message = $("#message");
	
	// onblur
	name.blur(validateName);
	email.blur(validateEmail);
	password.blur(validatePassword);
	confirm.blur(validateConfirm);
	message.blur(validateMessage);
	
	// onkeyup
	/*
	name.keyup(validateName);
	password.keyup(validatePassword);
	confirm.keyup(validateConfirm);
	message.keyup(validateMessage);
	*/

	// form submission
	form.submit(function() {
		if(validateName() & validateEmail() & validatePassword() & validateConfirm() & validateMessage())
			return true
		else
			return false;
	});
	
	//validation functions
	function validateEmail() {
		//testing regular expression
		var filter = /^[a-zA-Z0-9]+[a-zA-Z0-9_.-]+[a-zA-Z0-9_-]+@[a-zA-Z0-9]+[a-zA-Z0-9.-]+[a-zA-Z0-9]+.[a-z]{2,4}$/;
		// valid
		if (filter.test(email.val())) {
			email.removeClass("error");
			emailInfo.text("");
			emailInfo.removeClass("error");
			email.addClass("valid");
			return true;
		} else {
		// NOT valid
			email.addClass("error");
			emailInfo.text("Woah there cowboy! Please enter a valid e-mail address.");
			emailInfo.addClass("error");
			return false;
		}
	}
	
	function validateName() {
		// NOT valid
		if (name.val().length < 4) {
			name.addClass("error");
			nameInfo.text("We want names with more than 3 letters!");
			nameInfo.addClass("error");
			return false;
		} else {
		// valid
			name.removeClass("error");
			nameInfo.text("");
			nameInfo.removeClass("error");
			name.addClass("valid");
			return true;
		}
	}
	function validatePassword() {
		// NOT valid
		if (password.val().length <5) {
			password.addClass("error");
			passwordInfo.text("Unacceptable! Remember: At least 8 characters: letters, numbers and '_'");
			passwordInfo.addClass("error");
			return false;
		} else {
		// valid
			password.removeClass("error");
			passwordInfo.text("");
			passwordInfo.removeClass("error");
			password.addClass("valid");
			validateConfirm();
			return true;
		}
	}
	function validateConfirm() {
		// NOT valid
		if (password.val() != confirm.val()) {
			confirm.addClass("error");
			confirmInfo.text("Passwords do not match!");
			confirmInfo.addClass("error");
			return false;
		} else {
		// valid
			confirm.removeClass("error");
			confirmInfo.text("");
			confirmInfo.removeClass("error");
			confirm.addClass("valid");
			return true;
		}
	}
	function validateMessage(){
		// NOT valid
		if (message.val().length < 10) {
			message.addClass("error");
			return false;
		} else {
		// valid
			message.removeClass("error");
			message.addClass("valid");
			return true;
		}
	}
});