<!DOCTYPE html>
<html lang="en">
	<head>
		<title>HTML Form Exercise</title>
		<meta charset="utf-8" />
	</head>
	<body>
		<?php
			if ($_POST) {
				print_r($_POST);
			}
		?>
		<form action="form.php" method="post">
			<input type="submit" name="submit" id="submit" value="Submit" />
		</form>
	</body>
</html>