<!DOCTYPE html>
<html lang= "en-US">
	<head>
	<title> ~ Introduction to Unix </title>
	
	<link rel= "stylesheet" type= "text/css" href="Css_Unix.css">
	
	
	</head>

	<body>
	
	<div id="container">
		<?php 
			$selected = "tutor";
			$current_id = ' id="current"';
			include("menu.php");
		?>
	
		<h3> Accessing the Unix System </h3>

		<div id="content"> 
		
			<p>Unix is a multi-user system so more than one user can log in and out of the same system.

			<p>When booting up, the command will prompt you for username and password. The password will not display as you type it in - 
			this is done for security measures.

			<p>When logged in, a user can change their password. To do this, type <b>passwd</b>.

			<p>To log out of the system, simply type

			<p><b>exit</b>
			
		<form>
		<input type="button" value="Back" onClick="history.go(-1);return true;">
		</form>

		</div>
		<div id="footer"> &copy; Quang Nguyen 2013 </div>
	</div>
	
		
	</body>
</html>



